#include <stdio.h>
#include <stdlib.h>
#ifdef _XCALABLEMP
#include "xmp.h"
#endif
#include <mpi.h>

typedef unsigned long long	u64Int;
typedef signed long long	s64Int;

#define POLY			0x0000000000000007ULL
#define PERIOD			1317624576693539401LL

#define XMP_TABLE_SIZE		131072
#define PROCS			2
#define LOCAL_SIZE		(XMP_TABLE_SIZE/PROCS)
#define NUPDATE                 (4 * XMP_TABLE_SIZE)

u64Int Table[LOCAL_SIZE];
MPI_Win win;
int rank, size;
#pragma xmp nodes p(*)
//#pragma xmp coarray Table[*]

u64Int
HPCC_starts(s64Int n)
{
  int i, j;
  u64Int m2[64];
  u64Int temp, ran;

  while(n < 0) n += PERIOD;
  while(n > PERIOD) n -= PERIOD;
  if(n == 0) return 0x1;

  temp = 0x1;
  for(i = 0; i < 64; i++) {
    m2[i] = temp;
    temp = (temp << 1) ^ ((s64Int) temp < 0 ? POLY : 0);
    temp = (temp << 1) ^ ((s64Int) temp < 0 ? POLY : 0);
  }

  for(i = 62; i >= 0; i--)
    if((n >> i) & 1) break;

  ran = 0x2;
  while(i > 0) {
    temp = 0;
    for(j = 0; j < 64; j++)
      if((ran >> j) & 1) temp ^= m2[j];
    ran = temp;
    i -= 1;
    if((n >> i) & 1)
      ran = (ran << 1) ^ ((s64Int) ran < 0 ? POLY : 0);
  }

  return ran;
}

static void
RandomAccessUpdate(u64Int s)
{
  u64Int i, temp, buf;

  temp = s;
  for(i = 0; i < NUPDATE/128; i++) {
      temp = (temp << 1) ^ ((s64Int) temp < 0 ? POLY : 0);
      //      Table[temp%LOCAL_SIZE]:[(temp%XMP_TABLE_SIZE)/LOCAL_SIZE] ^= temp; 
      MPI_Win_fence(0, win);
      MPI_Get(&buf, 1, MPI_UNSIGNED_LONG_LONG, (int)((temp%XMP_TABLE_SIZE)/LOCAL_SIZE), 
	      (int)(temp%LOCAL_SIZE), 1, MPI_UNSIGNED_LONG_LONG, win);
      buf ^= temp;
      MPI_Put(&buf, 1, MPI_UNSIGNED_LONG_LONG, (int)((temp%XMP_TABLE_SIZE)/LOCAL_SIZE), 
	      (int)(temp%LOCAL_SIZE), 1, MPI_UNSIGNED_LONG_LONG, win);
      MPI_Win_fence(0, win);
  }

}

int
main( int argc, char **argv )
{
  u64Int i, b, s;
  double time, GUPs;

#ifdef _XCALABLEMP
  rank = xmp_get_rank();
  size = xmp_get_size();
#else
  rank = 0;
  size = 1;
#endif

  b = (u64Int)rank * LOCAL_SIZE;

  for(i = 0; i < LOCAL_SIZE; i++) Table[i] = b + i;
  s = HPCC_starts((s64Int)rank);

  MPI_Win_create(Table, LOCAL_SIZE, sizeof(u64Int), MPI_INFO_NULL, MPI_COMM_WORLD, &win);

  time = -MPI_Wtime();
#pragma xmp barrier
  RandomAccessUpdate(s);
#pragma xmp barrier
  time += MPI_Wtime();

  MPI_Win_free(&win);

  GUPs = (time > 0.0 ? 1.0 / time : -1.0);
  GUPs *= 1e-9*NUPDATE;

#pragma xmp reduction(+:GUPs) on p
  
  if(rank == 0) {
    printf("Executed on %d node(s)\n", size);
    printf("Time used: %.6f seconds\n", time);
    printf("%.9f Billion(10^9) updates per second [GUP/s]\n", GUPs);
  }

  return 0;
}
