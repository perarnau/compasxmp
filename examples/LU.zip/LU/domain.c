#include "applu.h"
#include "proto.h"
/* -------------------------------------------------------------------------- */
void domain()
{
  nx = nx0;
  ny = ny0;
  nz = nz0;
/* c--------------------------------------------------------------------- */
/* c   check the sub-domain size */
/* c--------------------------------------------------------------------- */
  if ( ( nx < 4 ) || ( ny < 4 ) || ( nz < 4 ) ){
#define FORMAT_2001   "     SUBDOMAIN SIZE IS TOO SMALL - " \
                    "\n     ADJUST PROBLEM SIZE OR NUMBER OF PROCESSORS" \
                    "\n     SO THAT NX, NY AND NZ ARE GREATER THAN OR EQUAL" \
                    "\n     TO 4 THEY ARE CURRENTLY%3d%3d%3d\n"
    printf(FORMAT_2001, nx, ny, nz);
    exit(1);
  } /* endif */

  if ( ( nx > isiz1 ) || ( ny > isiz2 ) || ( nz > isiz3 ) ){
#define FORMAT_2002   "     SUBDOMAIN SIZE IS TOO LARGE - " \
                    "\n     ADJUST PROBLEM SIZE OR NUMBER OF PROCESSORS" \
                    "\n     SO THAT NX, NY AND NZ ARE LESS THAN OR EQUAL TO " \
                    "\n     ISIZ1, ISIZ2 AND ISIZ3 RESPECTIVELY.  THEY ARE" \
                    "\n     CURRENTLY%4d%4d%4d\n"
    printf(FORMAT_2002, nx, ny, nz);
    exit(1);
  } /* endif */
/* c--------------------------------------------------------------------- */
/* c   set up the start and end in i and j extents for all processors */
/* c--------------------------------------------------------------------- */
  ist = 2;
  iend = nx - 1;

  jst = 2;
  jend = ny - 1;

  ii1 = 2;
  ii2 = nx0 - 1;
  ji1 = 2;
  ji2 = ny0 - 2;
  ki1 = 3;
  ki2 = nz0 - 1;
}
/* -------------------------------------------------------------------------- */
