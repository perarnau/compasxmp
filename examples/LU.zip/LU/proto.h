/* -*- c -*- */
/* -------------------------------------------------------------------------- */
void timer_clear( int n );
void timer_start( int n );
void timer_stop( int n );
double timer_read( int n );
/* -------------------------------------------------------------------------- */
void c_print_results( char   *name,
		      char   class,
		      int    n1,
		      int    n2,
		      int    n3,
		      int    niter,
		      int    nprocs,
		      double t,
		      double mops,
		      char   *optype,
		      int    passed_verification,
		      char   *npbversion, 
		      char   *compiletime,
                      char   *cc,
                      char   *clink,
                      char   *c_lib,
                      char   *c_inc,
                      char   *cflags,
                      char   *clinkflags );
/* -------------------------------------------------------------------------- */
void read_input();
int number_of_processors(); /* dummy */
void domain();
void setcoeff();
void setbv();
void exact(int i, int j, int k, double _u000ijk[5 +1]);
void setiv();
void erhs();
void ssor();
void error();
void pintgr();
void verify(double _xcr[5 +1], double _xce[5 +1], double xci, char *class, int *verified);
void rhs();
//void l2norm ( int ldx, int ldy, int ldz, int nx0, int ny0, int nz0,
//	      int ist, int iend, int jst, int jend,
//	      double _v[ldz +1][ldy/2*2+1 +1][ldx/2*2+1 +1][5 +1], double _summ[5 +1] );
void l2norm ( int nx0, int ny0, int nz0,
	      int ist, int iend, int jst, int jend,
	      double _v[ISIZE +1][ISIZE/2*2+1 +1][ISIZE/2*2+1 +1][5 +1], double _summ[5 +1] );
void InitSectionsN();
void SetLoopBounds();
void jacld(int l);
//void blts ( int ldmx, int ldmy, int ldmz, int l, double omega,
//	    double         _v[ldmz +1][ldmy/2*2+1 +1][ldmx/2*2+1 +1][5 +1],
//	    double _ldz[ldmy +1][ldmx/2*2+1 +1][5 +1][5 +1],
//	    double _ldy[ldmy +1][ldmx/2*2+1 +1][5 +1][5 +1],
//	    double _ldx[ldmy +1][ldmx/2*2+1 +1][5 +1][5 +1],
//	    double   _d[ldmy +1][ldmx/2*2+1 +1][5 +1][5 +1]);
void blts ( int l, double omega,
	    double   _v[ISIZE +1][ISIZE/2*2+1 +1][ISIZE/2*2+1 +1][5 +1], 
	    double _ldz[ISIZE +1][ISIZE/2*2+1 +1][5 +1][5 +1],
	    double _ldy[ISIZE +1][ISIZE/2*2+1 +1][5 +1][5 +1],
	    double _ldx[ISIZE +1][ISIZE/2*2+1 +1][5 +1][5 +1], 
	    double   _d[ISIZE +1][ISIZE/2*2+1 +1][5 +1][5 +1]);
void jacu(int l);
//void buts( int ldmx, int ldmy, int ldmz, int l, double omega,
//	   double         _v[ldmz +1][ldmy/2*2+1 +1][ldmx/2*2+1 +1][5 +1],
//	   double   _d[ldmy +1][ldmx/2*2+1 +1][5 +1][5 +1],
//	   double _udx[ldmy +1][ldmx/2*2+1 +1][5 +1][5 +1],
//	   double _udy[ldmy +1][ldmx/2*2+1 +1][5 +1][5 +1],
//	   double _udz[ldmy +1][ldmx/2*2+1 +1][5 +1][5 +1]);
void buts( int l, double omega,
	   double   _v[ISIZE +1][ISIZE/2*2+1 +1][ISIZE/2*2+1 +1][5 +1], 
	   double   _d[ISIZE +1][ISIZE/2*2+1 +1][5 +1][5 +1],
	   double _udx[ISIZE +1][ISIZE/2*2+1 +1][5 +1][5 +1],
	   double _udy[ISIZE +1][ISIZE/2*2+1 +1][5 +1][5 +1],
	   double _udz[ISIZE +1][ISIZE/2*2+1 +1][5 +1][5 +1]);
/* -------------------------------------------------------------------------- */

