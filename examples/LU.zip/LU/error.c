#include "applu.h"
#include "proto.h"
/* -------------------------------------------------------------------------- */
void error()
{
/* c--------------------------------------------------------------------- */
/* c   compute the solution error */
/* c--------------------------------------------------------------------- */
  int i, j, k, m;
  double _u000ijk[5 +1];
#define  u000ijk(a)  _u000ijk[a]

  for (m =1; m <=5; m ++){
    errnm(m) = 0.0e+00;
  }
#pragma xmp loop(j) on ProjArea(j)
  for (j =jst; j <=jend; j ++){
    for (k =2; k <=nz-1; k ++){
      for (i =ist; i <=iend; i ++){
	exact( i, j, k, _u000ijk );
	for (m =1; m <=5; m ++){
	  rsd(m,i,j,k) = u(m,i,j,k) - u000ijk(m);
	}
      }
    }
  }
  for (k=2; k<=nz-1; k++){
#pragma xmp loop(j) on ProjArea(j) reduction(+:_errnm)
    for (j=jst; j<=jend; j++){
      for (i=ist; i<=iend; i++){
	for (m =1; m <=5; m ++){
	  errnm(m) = errnm(m) + POW2(rsd(m,i,j,k));
	}
      }
    }
  }

  for (m =1; m <=5; m ++){
    errnm(m) = sqrt ( errnm(m) / ( (nx0-2)*(ny0-2)*(nz0-2) ) );
  }
}
/* -------------------------------------------------------------------------- */
