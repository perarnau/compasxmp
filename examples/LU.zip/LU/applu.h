/* -*- c -*- */
/* -------------------------------------------------------------------------- */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
/* -------------------------------------------------------------------------- */
#define TRUE  1
#define FALSE 0
#define dble(a)        ((double)(a))
#define float(a)       ((double)(a))
#define dabs(a)        (fabs(a))
#define POW2(a)        ((a)*(a))

#define max2(a, b)     ((a) > (b) ? (a) : (b))
#define max3(a, b, c)  ( (a) > (b) ? ( max2((a),(c)) ) : ( max2(b,c) ) )

#define mod(a,b)       ((a) % (b))
/* -------------------------------------------------------------------------- */
/* c--------------------------------------------------------------------- */
/* c   npbparams.h defines parameters that depend on the class and  */
/* c   number of nodes */
/* c--------------------------------------------------------------------- */
#include "npbparams.h"
/* -------------------------------------------------------------------------- */
#define  ipr_default    1
#define  omega_default  1.2e0
#define  tolrsd1_def    1.0e-08
#define  tolrsd2_def    1.0e-08
#define  tolrsd3_def    1.0e-08
#define  tolrsd4_def    1.0e-08
#define  tolrsd5_def    1.0e-08
#define  c1   1.40e+00
#define  c2   0.40e+00
#define  c3   1.00e-01
#define  c4   1.00e+00
#define  c5   1.40e+00

#ifdef MAIN
int nx, ny, nz, nx0, ny0, nz0, ist, iend, jst, jend, ii1, ii2, ji1, ji2, ki1, ki2;
double dxi, deta, dzeta, tx1, tx2, tx3, ty1, ty2, ty3, tz1, tz2, tz3;
#else /* MAIN */
extern int nx, ny, nz, nx0, ny0, nz0, ist, iend, jst, jend, ii1, ii2, ji1, ji2, ki1, ki2;
extern double dxi, deta, dzeta, tx1, tx2, tx3, ty1, ty2, ty3, tz1, tz2, tz3;
#endif /* MAIN */
#ifdef MAIN
double dx1, dx2, dx3, dx4, dx5, dy1, dy2, dy3, dy4, dy5, dz1, dz2, dz3, dz4, dz5, dssp;
#else /* MAIN */
extern double dx1, dx2, dx3, dx4, dx5, dy1, dy2, dy3, dy4, dy5, dz1, dz2, dz3, dz4, dz5, dssp;
#endif /* MAIN */

#ifdef MAIN
double     _u[isiz3 +1][isiz2/2*2+1 +1][isiz1/2*2+1 +1][5 +1];
double   _rsd[isiz3 +1][isiz2/2*2+1 +1][isiz1/2*2+1 +1][5 +1];
double  _frct[isiz3 +1][isiz2/2*2+1 +1][isiz1/2*2+1 +1][5 +1];
double  _flux[isiz1 +1][5 +1];
double  _flux_y[isiz2 +1][5 +1]; /* for erhs */
double _flux3[isiz3 +1][isiz2/2*2+1 +1][isiz1/2*2+1 +1][5 +1];
double    _qs[isiz3 +1][isiz2/2*2+1 +1][isiz1/2*2+1 +1];
double _rho_i[isiz3 +1][isiz2/2*2+1 +1][isiz1/2*2+1 +1];
int     _jlow[isiz1+isiz2+isiz3+3 +1];
int    _jhigh[isiz1+isiz2+isiz3+3 +1];
int     _ilow[isiz2/2*2+1 +1][isiz1+isiz2+isiz3+3 +1];
int    _ihigh[isiz2/2*2+1 +1][isiz1+isiz2+isiz3+3 +1];
#else /* MAIN */
extern double     _u[isiz3 +1][isiz2/2*2+1 +1][isiz1/2*2+1 +1][5 +1];
extern double   _rsd[isiz3 +1][isiz2/2*2+1 +1][isiz1/2*2+1 +1][5 +1];
extern double  _frct[isiz3 +1][isiz2/2*2+1 +1][isiz1/2*2+1 +1][5 +1];
extern double  _flux[isiz1 +1][5 +1];
extern double  _flux_y[isiz2 +1][5 +1]; /* for erhs */
extern double _flux3[isiz3 +1][isiz2/2*2+1 +1][isiz1/2*2+1 +1][5 +1];
extern double    _qs[isiz3 +1][isiz2/2*2+1 +1][isiz1/2*2+1 +1];
extern double _rho_i[isiz3 +1][isiz2/2*2+1 +1][isiz1/2*2+1 +1];
extern int     _jlow[isiz1+isiz2+isiz3+3 +1];
extern int    _jhigh[isiz1+isiz2+isiz3+3 +1];
extern int     _ilow[isiz2/2*2+1 +1][isiz1+isiz2+isiz3+3 +1];
extern int    _ihigh[isiz2/2*2+1 +1][isiz1+isiz2+isiz3+3 +1];
#endif /* MAIN */
#define      u(a,b,c,d)      _u[d][c][b][a]
#define    rsd(a,b,c,d)    _rsd[d][c][b][a]
#define   frct(a,b,c,d)   _frct[d][c][b][a]
#define   flux(a,b)       _flux[b][a]
#define flux_y(a,b)     _flux_y[b][a] /* for erhs */
#define  flux3(a,b,c,d)  _flux3[d][c][b][a]
#define     qs(a,b,c)       _qs[c][b][a]
#define  rho_i(a,b,c)    _rho_i[c][b][a]
#define   jlow(a)     _jlow[a]
#define  jhigh(a)    _jhigh[a]
#define   ilow(a,b)   _ilow[b][a]
#define  ihigh(a,b)  _ihigh[b][a]
/* -------------------------------------------------------------------------- */
#pragma xmp nodes P1(*)
#pragma xmp template ProjArea(0:64+1)  /* ProjArea(j) for isiz2=12 */
#define ISIZE 64
#pragma xmp distribute ProjArea(block) onto P1
#pragma xmp align      _u[*][j][*][*] with ProjArea(j)
#pragma xmp align    _rsd[*][j][*][*] with ProjArea(j)
#pragma xmp align   _frct[*][j][*][*] with ProjArea(j)
#pragma xmp align  _flux3[*][j][*][*] with ProjArea(j)
#pragma xmp align    _flux_y[j][*] with ProjArea(j) /* for erhs */
#pragma xmp shadow     _u[0][2][0][0] /* +-2 for rhs */
#pragma xmp shadow   _rsd[0][2][0][0] /* +-2 for erhs */
/*#pragma xmp shadow _frct[0][2][0][0]*/
#pragma xmp shadow _flux3[0][1][0][0] /* for rhs */
#pragma xmp shadow   _flux_y[1][0] /* for erhs */

#pragma xmp align     _qs[*][j][*] with ProjArea(j)
#pragma xmp align  _rho_i[*][j][*] with ProjArea(j)

double _phi1_x[ISIZE+1 +1][ISIZE+1 +1];
double _phi2_x[ISIZE+1 +1][ISIZE+1 +1];
double _phi1_y[ISIZE+1 +1][ISIZE+1 +1];
double _phi2_y[ISIZE+1 +1][ISIZE+1 +1];
#pragma xmp align  _phi1_x[j][*] with ProjArea(j)
#pragma xmp align  _phi2_x[j][*] with ProjArea(j)
#pragma xmp shadow _phi1_x[1][0]
#pragma xmp shadow _phi2_x[1][0]
#pragma xmp align  _phi1_y[*][j] with ProjArea(j)
#pragma xmp align  _phi2_y[*][j] with ProjArea(j)
#pragma xmp shadow _phi1_y[0][1]
#pragma xmp shadow _phi2_y[0][1]
/* -------------------------------------------------------------------------- */
#ifdef MAIN
int ipr, inorm;
#else /* MAIN */
extern int ipr, inorm;
#endif /* MAIN */
#ifdef MAIN
int itmax, invert;
double dt, omega, _tolrsd[5 +1], _rsdnm[5 +1], _errnm[5 +1], frc, ttotal;
#else /* MAIN */
extern int itmax, invert;
extern double dt, omega, _tolrsd[5 +1], _rsdnm[5 +1], _errnm[5 +1], frc, ttotal;
#endif /* MAIN */
#define tolrsd(a) _tolrsd[a]
#define  rsdnm(a)  _rsdnm[a]
#define  errnm(a)  _errnm[a]

#ifdef MAIN
double _a[isiz2 +1][isiz1/2*2+1 +1][5 +1][5 +1];
double _b[isiz2 +1][isiz1/2*2+1 +1][5 +1][5 +1];
double _c[isiz2 +1][isiz1/2*2+1 +1][5 +1][5 +1];
double _d[isiz2 +1][isiz1/2*2+1 +1][5 +1][5 +1];
#else /* MAIN */
extern double _a[isiz2 +1][isiz1/2*2+1 +1][5 +1][5 +1];
extern double _b[isiz2 +1][isiz1/2*2+1 +1][5 +1][5 +1];
extern double _c[isiz2 +1][isiz1/2*2+1 +1][5 +1][5 +1];
extern double _d[isiz2 +1][isiz1/2*2+1 +1][5 +1][5 +1];
#endif /* MAIN */
#define  a(a,b,c,d) _a[d][c][b][a]
#define  b(a,b,c,d) _b[d][c][b][a]
#define  c(a,b,c,d) _c[d][c][b][a]
#define  d(a,b,c,d) _d[d][c][b][a]
/* -------------------------------------------------------------------------- */
#pragma xmp align _a[j][*][*][*] with ProjArea(j)
#pragma xmp align _b[j][*][*][*] with ProjArea(j)
#pragma xmp align _c[j][*][*][*] with ProjArea(j)
#pragma xmp align _d[j][*][*][*] with ProjArea(j)
/* -------------------------------------------------------------------------- */
#ifdef MAIN
double _ce[13 +1][5 +1];
#else /* MAIN */
extern double _ce[13 +1][5 +1];
#endif /* MAIN */
#define ce(a,b) _ce[b][a]

#define  t_total    1
#define  t_rhsx     2
#define  t_rhsy     3
#define  t_rhsz     4
#define  t_rhs      5
#define  t_jacld    6
#define  t_blts     7
#define  t_jacu     8
#define  t_buts     9
#define  t_add     10
#define  t_l2norm  11
#define  t_last    11

#ifdef MAIN
double maxtime;
int timeron;
#else /* MAIN */
extern double maxtime;
extern int timeron;
#endif /* MAIN */
/* -------------------------------------------------------------------------- */

#ifdef MAIN
int section1, section2, section3;
int topseg, botseg, updown, updowne;
int jfirst, jlast, ifirst, ilast;
int xsize, ysize, zsize;
#else /* MAIN */
extern int section1, section2, section3;
extern int topseg, botseg, updown, updowne;
extern int jfirst, jlast, ifirst, ilast;
extern int xsize, ysize, zsize;
#endif /* MAIN */

/* -------------------------------------------------------------------------- */
