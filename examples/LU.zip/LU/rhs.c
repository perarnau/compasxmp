#include "applu.h"
#include "proto.h"
/* -------------------------------------------------------------------------- */
void rhs()
{
/* c--------------------------------------------------------------------- */
/* c   compute the right hand sides */
/* c--------------------------------------------------------------------- */
  int i, j, k, m;
  double q;
  double tmp;
  double u21, u31, u41;
  double u21i, u31i, u41i, u51i;
/*   double u21j, u31j, u41j, u51j; */
  double u21k, u31k, u41k, u51k;
  double u21im1, u31im1, u41im1, u51im1;
/*   double u21jm1, u31jm1, u41jm1, u51jm1; */
  double u21km1, u31km1, u41km1, u51km1;

#pragma xmp loop(j) on ProjArea(j)
  for (j =1; j <=ny; j ++){
    for (k =1; k <=nz; k ++){
      for (i =1; i <=nx; i ++){
	for (m =1; m <=5; m ++){
	  rsd(m,i,j,k) = - frct(m,i,j,k);
	} /* m */
	tmp = 1.0e+00 / u(1,i,j,k);
	rho_i(i,j,k) = tmp;
	qs(i,j,k) = 0.50e+00 * (  u(2,i,j,k) * u(2,i,j,k)
		    + u(3,i,j,k) * u(3,i,j,k)
                    + u(4,i,j,k) * u(4,i,j,k) ) * tmp;
      } /* i */
    } /* k */
  } /* j */

  if (timeron) timer_start(t_rhsx);

#pragma xmp loop(j) on ProjArea(j)
  for (j =jst; j <=jend; j ++){
    for (k =2; k <=nz - 1; k ++){
      for (i =1; i <=nx; i ++){
	flux(1,i) = u(2,i,j,k);
	u21 = u(2,i,j,k) * rho_i(i,j,k);

	q = qs(i,j,k);

	flux(2,i) = u(2,i,j,k) * u21 + c2 * ( u(5,i,j,k) - q );
	flux(3,i) = u(3,i,j,k) * u21;
	flux(4,i) = u(4,i,j,k) * u21;
	flux(5,i) = ( c1 * u(5,i,j,k) - c2 * q ) * u21;
      } /* i */

      for (i =ist; i <=iend; i ++){
	for (m =1; m <=5; m ++){
	  rsd(m,i,j,k) =  rsd(m,i,j,k) - tx2 * ( flux(m,i+1) - flux(m,i-1) );
	} /* m */
      } /* i */

      for (i =ist; i <=nx; i ++){
	tmp = rho_i(i,j,k);
	u21i = tmp * u(2,i,j,k);
	u31i = tmp * u(3,i,j,k);
	u41i = tmp * u(4,i,j,k);
	u51i = tmp * u(5,i,j,k);

	tmp = rho_i(i-1,j,k);
	u21im1 = tmp * u(2,i-1,j,k);
	u31im1 = tmp * u(3,i-1,j,k);
	u41im1 = tmp * u(4,i-1,j,k);
	u51im1 = tmp * u(5,i-1,j,k);

	flux(2,i) = (4.0e+00/3.0e+00) * tx3 * (u21i-u21im1);
	flux(3,i) = tx3 * ( u31i - u31im1 );
	flux(4,i) = tx3 * ( u41i - u41im1 );
	flux(5,i) = 0.50e+00 * ( 1.0e+00 - c1*c5 )
                   * tx3 * ( ( POW2(u21i  ) + POW2(u31i  ) + POW2(u41i  ) )
                           - ( POW2(u21im1) + POW2(u31im1) + POW2(u41im1) ) )
                   + (1.0e+00/6.0e+00)
                   * tx3 * ( POW2(u21i) - POW2(u21im1) )
	  + c1 * c5 * tx3 * ( u51i - u51im1 );
      } /* i */

      for (i =ist; i <=iend; i ++){
	rsd(1,i,j,k) = rsd(1,i,j,k)
                   + dx1 * tx1 * (            u(1,i-1,j,k)
                                  - 2.0e+00 * u(1,i,j,k)
			          +           u(1,i+1,j,k) );
	rsd(2,i,j,k) = rsd(2,i,j,k)
               + tx3 * c3 * c4 * ( flux(2,i+1) - flux(2,i) )
                   + dx2 * tx1 * (            u(2,i-1,j,k)
                                  - 2.0e+00 * u(2,i,j,k)
			          +           u(2,i+1,j,k) );
	rsd(3,i,j,k) = rsd(3,i,j,k)
               + tx3 * c3 * c4 * ( flux(3,i+1) - flux(3,i) )
                   + dx3 * tx1 * (            u(3,i-1,j,k)
                                  - 2.0e+00 * u(3,i,j,k)
			          +           u(3,i+1,j,k) );
	rsd(4,i,j,k) = rsd(4,i,j,k)
               + tx3 * c3 * c4 * ( flux(4,i+1) - flux(4,i) )
                   + dx4 * tx1 * (            u(4,i-1,j,k)
                                  - 2.0e+00 * u(4,i,j,k)
			          +           u(4,i+1,j,k) );
	rsd(5,i,j,k) = rsd(5,i,j,k)
               + tx3 * c3 * c4 * ( flux(5,i+1) - flux(5,i) )
                   + dx5 * tx1 * (            u(5,i-1,j,k)
                                  - 2.0e+00 * u(5,i,j,k)
			          +           u(5,i+1,j,k) );
      } /* i */
/* c--------------------------------------------------------------------- */
/* c   Fourth-order dissipation */
/* c--------------------------------------------------------------------- */
      for (m =1; m <=5; m ++){
	rsd(m,2,j,k) = rsd(m,2,j,k)
                - dssp * ( + 5.0e+00 * u(m,2,j,k)
                           - 4.0e+00 * u(m,3,j,k)
                           +           u(m,4,j,k) );
	rsd(m,3,j,k) = rsd(m,3,j,k)
                - dssp * ( - 4.0e+00 * u(m,2,j,k)
                           + 6.0e+00 * u(m,3,j,k)
                           - 4.0e+00 * u(m,4,j,k)
                           +           u(m,5,j,k) );
      } /* m */

      for (i =4; i <=nx - 3; i ++){
	for (m =1; m <=5; m ++){
	  rsd(m,i,j,k) = rsd(m,i,j,k)
                   - dssp * (            u(m,i-2,j,k)
                             - 4.0e+00 * u(m,i-1,j,k)
                             + 6.0e+00 * u(m,i,j,k)
                             - 4.0e+00 * u(m,i+1,j,k)
			     +           u(m,i+2,j,k) );
	} /* m */
      } /* i */

      for (m =1; m <=5; m ++){
	rsd(m,nx-2,j,k) = rsd(m,nx-2,j,k)
                - dssp * (             u(m,nx-4,j,k)
                           - 4.0e+00 * u(m,nx-3,j,k)
                           + 6.0e+00 * u(m,nx-2,j,k)
    		           - 4.0e+00 * u(m,nx-1,j,k)  );
	rsd(m,nx-1,j,k) = rsd(m,nx-1,j,k)
                - dssp * (             u(m,nx-3,j,k)
                           - 4.0e+00 * u(m,nx-2,j,k)
		           + 5.0e+00 * u(m,nx-1,j,k) );
      } /* m */

    } /* k */
  } /* j */
  if (timeron) timer_stop(t_rhsx);
/* -------------------------------------------------------------------------- */
/* c   eta-direction flux differences */
/* -------------------------------------------------------------------------- */
  if (timeron) timer_start(t_rhsy);
#pragma xmp loop(j) on ProjArea(j)
  for (j =1; j <=ny; j ++){
    for (k =2; k <=nz - 1; k ++){
      for (i =ist; i <=iend; i ++){
	flux3(1,i,j,k) = u(3,i,j,k);
	u31 = u(3,i,j,k) * rho_i(i,j,k);
	q = qs(i,j,k);

	flux3(2,i,j,k) = u(2,i,j,k) * u31;
	flux3(3,i,j,k) = u(3,i,j,k) * u31 + c2 * (u(5,i,j,k)-q);
	flux3(4,i,j,k) = u(4,i,j,k) * u31;
	flux3(5,i,j,k) = ( c1 * u(5,i,j,k) - c2 * q ) * u31;
      } /* i */
    } /* k */
  } /* j */

#pragma xmp reflect _flux3

  for (k=2; k<=nz-1; k++){
#pragma xmp loop(j) on ProjArea(j)
    for (j=jst; j<=jend; j++){
      for (i=ist; i<=iend; i++){
	for (m=1; m<=5; m++){
	  rsd(m,i,j,k) =  rsd(m,i,j,k) - ty2 * ( flux3(m,i,j+1,k)  - flux3(m,i,j-1,k ) );
	} /* m */
      } /* i */
    } /* j */
  } /* k */
     
#pragma xmp reflect _u
  for (k=2; k<=nz-1; k++){
#pragma xmp loop(j) on ProjArea(j)
    for (j=jst; j<=ny; j++){
      for (i=ist; i<=iend; i++){
	flux3(2,i,j,k) = 
	  ty3 * ( u(2,i,j,k) / u(1,i,j,k)
		  - u(2,i,j-1,k ) / u(1,i,j-1,k) );
      } /* i */
    } /* j */
  } /* k */

  for (k=2; k<=nz-1; k++){
#pragma xmp loop(j) on ProjArea(j)
    for (j=jst; j<=ny; j++){
      for (i=ist; i<=iend; i++){
	flux3(3,i,j,k) = 
	  (4.0e+00/3.0e+00)*ty3*( u(3,i,j,k) / u(1,i,j,k)
				  - u(3,i,j-1,k) / u(1,i,j-1,k) );
      } /* i */
    } /* j */
  } /* k */

  for (k=2; k<=nz-1; k++){
#pragma xmp loop(j) on ProjArea(j)
    for (j=jst; j<=ny; j++){
      for (i=ist; i<=iend; i++){
	flux3(4,i,j,k) =  ty3*( u(4,i,j,k) /u(1,i,j,k)
				- u(4,i,j-1,k) /u(1,i,j-1,k) );
      } /* i */
    } /* j */
  } /* k */

  for (k=2; k<=nz-1; k++){
#pragma xmp loop(j) on ProjArea(j)
    for (j=jst; j<=ny; j++){
      for (i=ist; i<=iend; i++){
        flux3(5,i,j,k) = 
                    0.50e+00 * ( 1.0e+00 - c1*c5 )*ty3*
                        ((POW2(u(2,i,j,k))
                  +       POW2(u(3,i,j,k))
                  +       POW2(u(4,i,j,k)))
                         /POW2(u(1,i,j,k))
                  -      (POW2(u(2,i,j-1,k))
                  +       POW2(u(3,i,j-1,k))
                  +       POW2(u(4,i,j-1,k)))
                         /POW2(u(1,i,j-1,k))
                         )
	  + (1.0e+00/6.0e+00)*ty3*( POW2(u(3,i,j,k)  /u(1,i,j,k)  )
				    - POW2(u(3,i,j-1,k)/u(1,i,j-1,k)) )
            + c1*c5*ty3*( u(5,i,j,k)/u(1,i,j,k)
                        - u(5,i,j-1,k )/u(1,i,j-1,k) );
      } /* i */
    } /* j */
  } /* k */
     
  for (k=2; k<=nz-1; k++){
#pragma xmp loop(j) on ProjArea(j)
    for (j=jst; j<=jend; j++){
      for (i=ist; i<=iend; i++){
	rsd(1,i,j,k) = 
                           rsd(1,i,j,k)
              + dy1 * ty1 * (u(1,i,j-1,k)
                 - 2.0e+00 * u(1,i,j,k)
		           + u(1,i,j+1,k) );
      } /* i */
    } /* j */
  } /* k */

#pragma xmp reflect _flux3
  for (k=2; k<=nz-1; k++){
#pragma xmp loop(j) on ProjArea(j)
    for (j=jst; j<=jend; j++){
      for (i=ist; i<=iend; i++){
	rsd(2,i,j,k) = 
                           rsd(2,i,j,k)
      + ty3 * c3 * c4 * ( flux3(2,i,j+1,k) 
                        - flux3(2,i,j,k) )
              + dy2 * ty1 * (u(2,i,j-1,k)
                 - 2.0e+00 * u(2,i,j,k)
		           + u(2,i,j+1,k) );
      } /* i */
    } /* j */
  } /* k */

  for (k=2; k<=nz-1; k++){
#pragma xmp loop(j) on ProjArea(j)
    for (j=jst; j<=jend; j++){
      for (i=ist; i<=iend; i++){
	rsd(3,i,j,k) = 
                           rsd(3,i,j,k)
      + ty3 * c3 * c4 * ( flux3(3,i,j+1,k) 
                        - flux3(3,i,j,k) )
              + dy3 * ty1 * (u(3,i,j-1,k)
                 - 2.0e+00 * u(3,i,j,k)
		           + u(3,i,j+1,k) );
      } /* i */
    } /* j */
  } /* k */

  for (k=2; k<=nz-1; k++){
#pragma xmp loop(j) on ProjArea(j)
    for (j=jst; j<=jend; j++){
      for (i=ist; i<=iend; i++){
	rsd(4,i,j,k) = 
                           rsd(4,i,j,k)
      + ty3 * c3 * c4 * ( flux3(4,i,j+1,k) 
                        - flux3(4,i,j,k) )
              + dy4 * ty1 * (u(4,i,j-1,k)
                 - 2.0e+00 * u(4,i,j,k)
		           + u(4,i,j+1,k) );
      } /* i */
    } /* j */
  } /* k */

  for (k=2; k<=nz-1; k++){
#pragma xmp loop(j) on ProjArea(j)
    for (j=jst; j<=jend; j++){
      for (i=ist; i<=iend; i++){
	rsd(5,i,j,k) = 
                           rsd(5,i,j,k)
      + ty3 * c3 * c4 * ( flux3(5,i,j+1,k) 
                        - flux3(5,i,j,k) )
              + dy5 * ty1 * (u(5,i,j-1,k)
                 - 2.0e+00 * u(5,i,j,k)
		           + u(5,i,j+1,k) );
      } /* i */
    } /* j */
  } /* k */

  //#if 1
  //  if(isiz2/nprocs < 5){
  //    printf("ERROR: rhs: isiz2/nprocs < 5",*);
  //    exit(1);
  //  }
  //#endif
#pragma xmp task on ProjArea(4)
{
  for (k=2; k<=nz-1; k++){
    for (i=ist; i<=iend; i++){
      for (m=1; m<=5; m++){
	rsd(m,i,2,k) = rsd(m,i,2,k)
                - dssp * ( + 5.0e+00 * u(m,i,2,k)
                           - 4.0e+00 * u(m,i,3,k)
                           +           u(m,i,4,k) );
      } /* m */
    } /* i */
  } /* k */
}
#pragma xmp task on ProjArea(5)
{
  for (k=2; k<=nz-1; k++){
    for (i=ist; i<=iend; i++){
      for (m=1; m<=5; m++){
	rsd(m,i,3,k) = rsd(m,i,3,k)
                - dssp * ( - 4.0e+00 * u(m,i,2,k)
                           + 6.0e+00 * u(m,i,3,k)
                           - 4.0e+00 * u(m,i,4,k)
                           +           u(m,i,5,k) );
      } /* m */
    } /* i */
  } /* k */
 }
  for (k=2; k<=nz-1; k++){
#pragma xmp loop(j) on ProjArea(j)
    for (j=4; j<=ny-3; j++){
      for (i=ist; i<=iend; i++){
        for (m=1; m<=5; m++){
	  rsd(m,i,j  ,k) = rsd(m,i,j  ,k)
                  - dssp * (            u(m,i,j-2,k)
                            - 4.0e+00 * u(m,i,j-1,k)
                            + 6.0e+00 * u(m,i,j  ,k)
                            - 4.0e+00 * u(m,i,j+1,k)
			    +           u(m,i,j+2,k) );
        } /* m */
      } /* i */
    } /* j */
  } /* k */

#pragma xmp task on ProjArea(ny-4)
{
  for (k=2; k<=nz-1; k++){
    for (i=ist; i<=iend; i++){
      for (m=1; m<=5; m++){
	rsd(m,i,ny-2,k) = rsd(m,i,ny-2,k)
                - dssp * (             u(m,i,ny-4,k)
                           - 4.0e+00 * u(m,i,ny-3,k)
                           + 6.0e+00 * u(m,i,ny-2,k)
		           - 4.0e+00 * u(m,i,ny-1,k)  );
      } /* m */
    } /* i */
  } /* k */
}
#pragma xmp task on ProjArea(ny-3)
{
  for (k=2; k<=nz-1; k++){
    for (i=ist; i<=iend; i++){
      for (m=1; m<=5; m++){
	rsd(m,i,ny-1,k) = rsd(m,i,ny-1,k)
                - dssp * (            u(m,i,ny-3,k)
                          - 4.0e+00 * u(m,i,ny-2,k)
		          + 5.0e+00 * u(m,i,ny-1,k) );
      } /* m */
    } /* i */
  } /* k */
}
  if (timeron) timer_stop(t_rhsy);
/* -------------------------------------------------------------------------- */
/* c   zeta-direction flux differences */
/* -------------------------------------------------------------------------- */
  if (timeron) timer_start(t_rhsz);
#pragma xmp loop(j) on ProjArea(j)
  for (j =jst; j <=jend; j ++){
    for (i =ist; i <=iend; i ++){
      for (k =1; k <=nz; k ++){
	flux(1,k) = u(4,i,j,k);
	u41 = u(4,i,j,k) * rho_i(i,j,k);

	q = qs(i,j,k);

	flux(2,k) = u(2,i,j,k) * u41;
	flux(3,k) = u(3,i,j,k) * u41;
	flux(4,k) = u(4,i,j,k) * u41 + c2 * (u(5,i,j,k)-q);
	flux(5,k) = ( c1 * u(5,i,j,k) - c2 * q ) * u41;
      } /* k */

      for (k =2; k <=nz - 1; k ++){
	for (m =1; m <=5; m ++){
	  rsd(m,i,j,k) =  rsd(m,i,j,k) - tz2 * ( flux(m,k+1) - flux(m,k-1) );
	} /* m */
      } /* k */

      for (k =2; k <=nz; k ++){
	tmp = rho_i(i,j,k);
	u21k = tmp * u(2,i,j,k);
	u31k = tmp * u(3,i,j,k);
	u41k = tmp * u(4,i,j,k);
	u51k = tmp * u(5,i,j,k);

	tmp = rho_i(i,j,k-1);
	u21km1 = tmp * u(2,i,j,k-1);
	u31km1 = tmp * u(3,i,j,k-1);
	u41km1 = tmp * u(4,i,j,k-1);
	u51km1 = tmp * u(5,i,j,k-1);

	flux(2,k) = tz3 * ( u21k - u21km1 );
	flux(3,k) = tz3 * ( u31k - u31km1 );
	flux(4,k) = (4.0e+00/3.0e+00) * tz3 * (u41k-u41km1);
	flux(5,k) = 0.50e+00 * ( 1.0e+00 - c1*c5 )
                   * tz3 * ( ( POW2(u21k  ) + POW2(u31k  ) + POW2(u41k  ) )
                           - ( POW2(u21km1) + POW2(u31km1) + POW2(u41km1) ) )
                   + (1.0e+00/6.0e+00)
                   * tz3 * ( POW2(u41k) - POW2(u41km1) )
	           + c1 * c5 * tz3 * ( u51k - u51km1 );
      } /* k */

      for (k =2; k <=nz - 1; k ++){
	rsd(1,i,j,k) = rsd(1,i,j,k)
                   + dz1 * tz1 * (            u(1,i,j,k-1)
                                  - 2.0e+00 * u(1,i,j,k)
			          +           u(1,i,j,k+1) );
	rsd(2,i,j,k) = rsd(2,i,j,k)
               + tz3 * c3 * c4 * ( flux(2,k+1) - flux(2,k) )
                   + dz2 * tz1 * (            u(2,i,j,k-1)
                                  - 2.0e+00 * u(2,i,j,k)
			          +           u(2,i,j,k+1) );
	rsd(3,i,j,k) = rsd(3,i,j,k)
               + tz3 * c3 * c4 * ( flux(3,k+1) - flux(3,k) )
                   + dz3 * tz1 * (            u(3,i,j,k-1)
                                  - 2.0e+00 * u(3,i,j,k)
			          +           u(3,i,j,k+1) );
	rsd(4,i,j,k) = rsd(4,i,j,k)
               + tz3 * c3 * c4 * ( flux(4,k+1) - flux(4,k) )
                   + dz4 * tz1 * (            u(4,i,j,k-1)
                                  - 2.0e+00 * u(4,i,j,k)
			          +           u(4,i,j,k+1) );
	rsd(5,i,j,k) = rsd(5,i,j,k)
               + tz3 * c3 * c4 * ( flux(5,k+1) - flux(5,k) )
                   + dz5 * tz1 * (            u(5,i,j,k-1)
                                  - 2.0e+00 * u(5,i,j,k)
			          +           u(5,i,j,k+1) );
      } /* k */
/* c--------------------------------------------------------------------- */
/* c   fourth-order dissipation */
/* c--------------------------------------------------------------------- */
      for (m =1; m <=5; m ++){
	rsd(m,i,j,2) = rsd(m,i,j,2)
                - dssp * ( + 5.0e+00 * u(m,i,j,2)
                           - 4.0e+00 * u(m,i,j,3)
                           +           u(m,i,j,4) );
	rsd(m,i,j,3) = rsd(m,i,j,3)
                - dssp * ( - 4.0e+00 * u(m,i,j,2)
                           + 6.0e+00 * u(m,i,j,3)
                           - 4.0e+00 * u(m,i,j,4)
                           +           u(m,i,j,5) );
      } /* m */

      for (k =4; k <=nz - 3; k ++){
	for (m =1; m <=5; m ++){
	  rsd(m,i,j,k) = rsd(m,i,j,k)
                   - dssp * (            u(m,i,j,k-2)
                             - 4.0e+00 * u(m,i,j,k-1)
                             + 6.0e+00 * u(m,i,j,k)
                             - 4.0e+00 * u(m,i,j,k+1)
	  		     +           u(m,i,j,k+2) );
	} /* m */
      } /* k */

      for (m =1; m <=5; m ++){
	rsd(m,i,j,nz-2) = rsd(m,i,j,nz-2)
                - dssp * (             u(m,i,j,nz-4)
                           - 4.0e+00 * u(m,i,j,nz-3)
                           + 6.0e+00 * u(m,i,j,nz-2)
		           - 4.0e+00 * u(m,i,j,nz-1) );
	rsd(m,i,j,nz-1) = rsd(m,i,j,nz-1)
                - dssp * (             u(m,i,j,nz-3)
                           - 4.0e+00 * u(m,i,j,nz-2)
		           + 5.0e+00 * u(m,i,j,nz-1) );
      } /* m */

    } /* i */
  } /* j */
  if (timeron) timer_stop(t_rhsz);
}
/* -------------------------------------------------------------------------- */
