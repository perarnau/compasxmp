/* -*- c -*- */
/* -------------------------------------------------------------------------- */
/* class = A */
#define  isiz1  64
#define  isiz2  64
#define  isiz3  64
#define  itmax_default  250
#define  inorm_default  250
#define  dt_default   2.0e0

#define NPBVERSION "3.0"
#define COMPILETIME "19 Jan 2011"
#define cs1 ""
#define cs2 "$(F77)"
#define cs3 "(none)"
#define cs4 "(none)"
#define cs5 "-O"
#define cs6 "-O"
#define cs7 "randi8"
#define CC         cs1
#define CLINK      cs2
#define C_LIB      cs3
#define C_INC      cs4
#define CFLAGS     cs5
#define CLINKFLAGS cs6
/* -------------------------------------------------------------------------- */
