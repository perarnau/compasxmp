#include "applu.h"
#include "proto.h"
/* -------------------------------------------------------------------------- */
#define     v(a,b,c,d)    _v[d][c][b][a]
#define  summ(a)       _summ[a]
//void l2norm ( int ldx, int ldy, int ldz, int nx0, int ny0, int nz0,
//	      int ist, int iend, int jst, int jend,
//	      double _v[ldz +1][ldy/2*2+1 +1][ldx/2*2+1 +1][5 +1],
//	      double _summ[5 +1] )
void l2norm ( int nx0, int ny0, int nz0,
	      int ist, int iend, int jst, int jend,
	      double _v[ISIZE +1][ISIZE/2*2+1 +1][ISIZE/2*2+1 +1][5 +1],
	      double _summ[5 +1] )
{
#pragma xmp align    _v[*][j][*][*] with ProjArea(j)
#pragma xmp shadow   _v[0][2][0][0]
/* c--------------------------------------------------------------------- */
/* c   to compute the l2-norm of vector v. */
/* c--------------------------------------------------------------------- */
  int i, j, k, m;
  for (m = 1; m <= 5; m ++){
    summ(m) = 0.0;
  }
  for (k=2; k<=nz0-1; k++){
#pragma xmp loop(j) on ProjArea(j) reduction(+:_summ)
    for (j=jst; j<=jend; j++){
      for (i=ist; i<=iend; i++){
	for (m =1; m <=5; m ++){
	  summ(m) = summ(m) + v(m,i,j,k) * v(m,i,j,k);
	}
      }
    }
  }
  for (m =1; m <=5; m ++){
    summ(m) = sqrt ( summ(m) / ( (nx0-2)*(ny0-2)*(nz0-2) ) );
  }
}
/* -------------------------------------------------------------------------- */
