#include "applu.h"
#include "proto.h"
/* -------------------------------------------------------------------------- */
void setbv()
{
/* c--------------------------------------------------------------------- */
/* c   set the boundary values of dependent variables */
/* c--------------------------------------------------------------------- */
  int i, j, k, m;
  double _temp1[5 +1], _temp2[5 +1];
#define  temp1(m)  _temp1[m]
#define  temp2(m)  _temp2[m]
/* c--------------------------------------------------------------------- */
/* c   set the dependent variable values along the top and bottom faces */
/* c--------------------------------------------------------------------- */
#pragma xmp loop(j) on ProjArea(j)
  for (j = 1; j<= ny; j++){
    for (i = 1; i<= nx; i++){
      exact( i, j,  1, _temp1 );
      exact( i, j, nz, _temp2 );
      for (m = 1; m<= 5; m++){
	u( m, i, j,  1 ) = temp1(m);
	u( m, i, j, nz ) = temp2(m);
      } /* m */
    } /* i */
  } /* j */
/* c--------------------------------------------------------------------- */
/* c   set the dependent variable values along north and south faces */
/* c--------------------------------------------------------------------- */
#pragma xmp task on ProjArea(1)
{
  for (k = 1; k<= nz; k++){
    for (i = 1; i<= nx; i++){
      exact( i,  1, k, _temp1 );
      /* exact( i, ny, k, _temp2 ); */
      for (m = 1; m<= 5; m++){
	u( m, i,  1, k ) = temp1(m);
	/* u( m, i, ny, k ) = temp2(m); */
      } /* m */
    } /* i */
  } /* k */
}
#pragma xmp task on ProjArea(ny)
{
  for (k = 1; k<= nz; k++){
    for (i = 1; i<= nx; i++){
      /* exact( i,  1, k, _temp1 ); */
      exact( i, ny, k, _temp2 );
      for (m = 1; m<= 5; m++){
	/* u( m, i,  1, k ) = temp1(m); */
	u( m, i, ny, k ) = temp2(m);
      } /* m */
    } /* i */
  } /* k */
}
/* c--------------------------------------------------------------------- */
/* c   set the dependent variable values along east and west faces */
/* c--------------------------------------------------------------------- */
  for (k = 1; k<= nz; k++){
#pragma xmp loop(j) on ProjArea(j)
    for (j = 1; j<= ny; j++){
      exact(  1, j, k, _temp1 );
      exact( nx, j, k, _temp2 );
      for (m = 1; m<= 5; m++){
	u( m,  1, j, k ) = temp1(m);
	u( m, nx, j, k ) = temp2(m);
      } /* m */
    } /* j */
  } /* k */
}
/* -------------------------------------------------------------------------- */
