#include "applu.h"
#include "proto.h"
/* -------------------------------------------------------------------------- */
void setiv()
{
/* c--------------------------------------------------------------------- */
/* c */
/* c   set the initial values of independent variables based on tri-linear */
/* c   interpolation of boundary values in the computational space. */
/* c */
/* c--------------------------------------------------------------------- */
  int i, j, k, m;
  double xi, eta, zeta, pxi, peta, pzeta;
  double _ue_1jk[5 +1], _ue_nx0jk[5 +1], _ue_i1k[5 +1], _ue_iny0k[5 +1], _ue_ij1[5 +1], _ue_ijnz[5 +1];
#define    ue_1jk(m)    _ue_1jk[m]
#define  ue_nx0jk(m)  _ue_nx0jk[m]
#define    ue_i1k(m)    _ue_i1k[m]
#define  ue_iny0k(m)  _ue_iny0k[m]
#define    ue_ij1(m)    _ue_ij1[m]
#define   ue_ijnz(m)   _ue_ijnz[m]

  for (k = 2; k<= nz - 1; k++){
    zeta = ( dble (k-1) ) / (nz-1);
#pragma xmp loop(j) on ProjArea(j)
    for (j = 2; j<= ny - 1; j++){
      eta = ( dble (j-1) ) / (ny0-1);
      for (i = 2; i<= nx - 1; i++){
	xi = ( dble (i-1) ) / (nx0-1);
	exact (  1,   j,  k, _ue_1jk  );
	exact (nx0,   j,  k, _ue_nx0jk);
	exact (  i,   1,  k, _ue_i1k  );
	exact (  i, ny0,  k, _ue_iny0k);
	exact (  i,   j,  1, _ue_ij1  );
	exact (  i,   j, nz, _ue_ijnz );

	for (m = 1; m<= 5; m++){
	  pxi =   ( 1.0 -   xi ) * ue_1jk(m) + xi   * ue_nx0jk(m);
	  peta =  ( 1.0 -  eta ) * ue_i1k(m) + eta  * ue_iny0k(m);
	  pzeta = ( 1.0 - zeta ) * ue_ij1(m) + zeta * ue_ijnz(m);

	  u( m, i, j, k ) = pxi + peta + pzeta
                      - pxi * peta - peta * pzeta - pzeta * pxi
	    + pxi * peta * pzeta;
	} /* m */
      } /* i */
    } /* j */
  } /* k */
}
/* -------------------------------------------------------------------------- */
