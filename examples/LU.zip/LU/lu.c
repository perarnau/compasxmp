#define MAIN
#include "applu.h"
#include "proto.h"
#ifdef _XCALABLEMP
#include "xmp.h"
#endif
/* -------------------------------------------------------------------------- */
int main()
{
/* c--------------------------------------------------------------------- */
/* c   driver for the performance evaluation of the solver for */
/* c   five coupled parabolic/elliptic partial differential equations. */
/* c--------------------------------------------------------------------- */
  char class;
  int verified;
  int i, nprocs;
  double mflops, t, tmax, _trecs[t_last +1];
  char *_t_names[t_last +1];
#define    trecs(a)   _trecs[a]
#define  t_names(a) _t_names[a]
/* c--------------------------------------------------------------------- */
/* c     Setup info for timers */
/* c--------------------------------------------------------------------- */
  
  FILE *fstatus;
  timeron = FALSE;

  read_input();

  /* Add by mnakao */
  /* For checking task directives in rhs.c and exact_rhs.c */
  /* index 1:4 and index grid_points(3)-5:gridpoints(3)-2 are
     on the same node. */
#ifdef _XCALABLEMP
  nprocs = xmp_get_size();
#else
  nprocs = 1;
#endif

  int block_size = ceil((double)(isiz1+2) / nprocs);

  if(1/block_size != 5/block_size){
#pragma xmp task on ProjArea(0)
    fprintf(stderr, "Error: NP(%d) is too big.\n", nprocs);
    exit(0);
  }
  if((isiz1-1)/block_size != (isiz1-4)/block_size){
#pragma xmp task on ProjArea(0)
    fprintf(stderr, "Error: NP(%d) is too big.\n", nprocs);
    exit(0);
  }
  /* End adding by mnakao */

  domain();

  setcoeff();

  setbv();

  setiv();

  erhs();

  ssor();

  error();

  pintgr();

  verify ( _rsdnm, _errnm, frc, &class /* out */, &verified /* out */ );

  mflops = float(itmax)*(1984.77*float( nx0 ) * float( ny0 ) * float( nz0 )
			 -10923.3*POW2(float( nx0+ny0+nz0 )/3.0)
			 +27770.9* float( nx0+ny0+nz0 )/3.0
			 -144010.0)
    / (maxtime*1000000.0);

#pragma xmp task on ProjArea(0)
  c_print_results("LU", class, nx0, ny0, nz0, itmax, nprocs,
		  maxtime, mflops, "          floating point", verified, 
		  NPBVERSION, COMPILETIME, CC, CLINK, C_LIB, C_INC, CFLAGS, CLINKFLAGS);

/* c--------------------------------------------------------------------- */
/* c      More timers */
/* c--------------------------------------------------------------------- */
  if (!timeron) goto LABEL_999;
  printf("  SECTION     Time (secs)\n");

  for (i=1; i<=t_last; i++){
    trecs(i) = timer_read(i);
  }
  tmax = maxtime;
  if ( tmax == 0.0 ) tmax = 1.0;
  for (i=1; i<=t_last; i++){
#define  FORMAT_810     "  %-8s:%9.3f  (%6.2f%%)\n"
#define  FORMAT_820     "     --> total %8s:%9.3f  (%6.2f%%)\n"
    printf(FORMAT_810, t_names(i), trecs(i), trecs(i)*100.0/tmax);
    if (i == t_rhs){
      t = trecs(t_rhsx) + trecs(t_rhsy) + trecs(t_rhsz);
      printf(FORMAT_820, "sub-rhs", t, t*100.0/tmax);
      t = trecs(i) - t;
      printf(FORMAT_820, "rest-rhs", t, t*100.0/tmax);
    } /* endif */
  }

 LABEL_999:
  exit(0);
}
/* -------------------------------------------------------------------------- */
