#include "applu.h"
#include "proto.h"
/* -------------------------------------------------------------------------- */
double  _u0l[isiz2 +1][isiz1/2*2+1 +1][5 +1];
double  _uxl[isiz2 +1][isiz1/2*2+1 +1][5 +1];
double  _uyl[isiz2 +1][isiz1/2*2+1 +1][5 +1];
double  _uzl[isiz2 +1][isiz1/2*2+1 +1][5 +1];
double _uylt[isiz2 +1][isiz1/2*2+1 +1][5 +1];
#define   u0l(a,b,c)  _u0l[c][b][a]
#define   uxl(a,b,c)  _uxl[c][b][a]
#define   uyl(a,b,c)  _uyl[c][b][a]
#define   uzl(a,b,c)  _uzl[c][b][a]
#define  uylt(a,b,c) _uylt[c][b][a]

#pragma xmp align   _u0l[j][*][*] with ProjArea(j)
#pragma xmp align   _uxl[j][*][*] with ProjArea(j)
#pragma xmp align   _uyl[j][*][*] with ProjArea(j)
#pragma xmp align   _uzl[j][*][*] with ProjArea(j)
#pragma xmp align  _uylt[j][*][*] with ProjArea(j)

#pragma xmp shadow  _u0l[1:1][0][0]
#pragma xmp shadow  _uxl[1:1][0][0]
#pragma xmp shadow  _uyl[1:1][0][0]
#pragma xmp shadow  _uzl[1:1][0][0]
#pragma xmp shadow _uylt[1:1][0][0]

void jacu(int l)
{
/* c--------------------------------------------------------------------- */
/* c   compute the upper triangular part of the jacobian matrix */
/* c--------------------------------------------------------------------- */
  int i, j, idx, k;
  double r43, c1345, c34, tmp1, tmp2, tmp3;
  double _u0[5 +1], _ux[5 +1], _uy[5 +1], _uz[5 +1];
#define  u0(a)  _u0[a]
#define  ux(a)  _ux[a]
#define  uy(a)  _uy[a]
#define  uz(a)  _uz[a]

  r43 = ( 4.0e+00 / 3.0e+00 );
  c1345 = c1 * c3 * c4 * c5;
  c34 = c3 * c4;

#pragma xmp reflect _u
#pragma xmp loop(j) on ProjArea(j)
  for (j=jlow(l); j<=jhigh(l); j++){
    for (i=ilow(l,j); i<=ihigh(l,j); i++){
      k = l-i-j;
      for (idx =1; idx <=5; idx ++){
	u0l(idx,i,j) = u(idx,i,j,k);
	uxl(idx,i,j) = u(idx,i+1,j,k);
	uzl(idx,i,j) = u(idx,i,j,k+1);
      } /* idx */
    } /* i */
  } /* j */

#pragma xmp loop(j) on ProjArea(j)
  for (j=jlow(l); j<=jhigh(l); j++){
    for (i=ilow(l,j); i<=ihigh(l,j); i++){
      k = l-i-j;
      for (idx =1; idx <=5; idx ++){
	uyl(idx,i,j+1) = u(idx,i,j+1,k);
      } /* idx */
    } /* i */
  } /* j */

  //#pragma xmp reflect _uyl
#pragma xmp loop(j) on ProjArea(j)
  for (j=jlow(l); j<=jhigh(l); j++){
    for (i=jlow(l); i<=jhigh(l); i++){
      for (idx=1; idx<=5; idx++){
	uylt(idx,i,j) = uyl(idx,i,j+1);
      } /* idx */
    } /* i */
  } /* j */

#pragma xmp loop(j) on ProjArea(j)
  for (j=jlow(l); j<=jhigh(l); j++){
    for (i=ilow(l,j); i<=ihigh(l,j); i++){

      for (idx =1; idx <=5; idx ++){
	u0(idx) = u0l(idx,i,j);
	ux(idx) = uxl(idx,i,j);
	uy(idx) = uylt(idx,i,j);
	uz(idx) = uzl(idx,i,j);
      } /* idx */

/* c--------------------------------------------------------------------- */
/* c   form the block daigonal */
/* c--------------------------------------------------------------------- */
      tmp1 = 1.0e+00 / u0(1);
      tmp2 = tmp1 * tmp1;
      tmp3 = tmp1 * tmp2;

      d(1,1,i,j) =  1.0e+00
	+ dt * 2.0e+00 * (   tx1 * dx1
			     + ty1 * dy1
			     + tz1 * dz1 );
      d(1,2,i,j) =  0.0e+00;
      d(1,3,i,j) =  0.0e+00;
      d(1,4,i,j) =  0.0e+00;
      d(1,5,i,j) =  0.0e+00;

      d(2,1,i,j) =  dt * 2.0e+00
                * ( - tx1 * r43 - ty1 - tz1 )
	* ( c34 * tmp2 * u0(2) );
      d(2,2,i,j) =  1.0e+00
               + dt * 2.0e+00 * c34 * tmp1
               * (  tx1 * r43 + ty1 + tz1 )
               + dt * 2.0e+00 * (   tx1 * dx2
                                  + ty1 * dy2
				    + tz1 * dz2  );
      d(2,3,i,j) = 0.0e+00;
      d(2,4,i,j) = 0.0e+00;
      d(2,5,i,j) = 0.0e+00;

      d(3,1,i,j) = dt * 2.0e+00
                * ( - tx1 - ty1 * r43 - tz1 )
	* ( c34 * tmp2 * u0(3) );
      d(3,2,i,j) = 0.0e+00;
      d(3,3,i,j) = 1.0e+00
              + dt * 2.0e+00 * c34 * tmp1
                   * (  tx1 + ty1 * r43 + tz1 )
              + dt * 2.0e+00 * (  tx1 * dx3
                                + ty1 * dy3
				  + tz1 * dz3 );
      d(3,4,i,j) = 0.0e+00;
      d(3,5,i,j) = 0.0e+00;

      d(4,1,i,j) = dt * 2.0e+00
                * ( - tx1 - ty1 - tz1 * r43 )
	* ( c34 * tmp2 * u0(4) );
      d(4,2,i,j) = 0.0e+00;
      d(4,3,i,j) = 0.0e+00;
      d(4,4,i,j) = 1.0e+00
              + dt * 2.0e+00 * c34 * tmp1
                   * (  tx1 + ty1 + tz1 * r43 )
              + dt * 2.0e+00 * (  tx1 * dx4
                                + ty1 * dy4
				  + tz1 * dz4 );
      d(4,5,i,j) = 0.0e+00;

      d(5,1,i,j) = -dt * 2.0e+00
       * ( ( ( tx1 * ( r43*c34 - c1345 )
          + ty1 * ( c34 - c1345 )
          + tz1 * ( c34 - c1345 ) ) * ( POW2(u0(2)) )
        + ( tx1 * ( c34 - c1345 )
          + ty1 * ( r43*c34 - c1345 )
          + tz1 * ( c34 - c1345 ) ) * ( POW2(u0(3)) )
        + ( tx1 * ( c34 - c1345 )
          + ty1 * ( c34 - c1345 )
          + tz1 * ( r43*c34 - c1345 ) ) * ( POW2(u0(4)) )
           ) * tmp3
	   + ( tx1 + ty1 + tz1 ) * c1345 * tmp2 * u0(5) );

      d(5,2,i,j) = dt * 2.0e+00
      * ( tx1 * ( r43*c34 - c1345 )
        + ty1 * (     c34 - c1345 )
	  + tz1 * (     c34 - c1345 ) ) * tmp2 * u0(2);
      d(5,3,i,j) = dt * 2.0e+00
      * ( tx1 * ( c34 - c1345 )
        + ty1 * ( r43*c34 -c1345 )
	  + tz1 * ( c34 - c1345 ) ) * tmp2 * u0(3);
      d(5,4,i,j) = dt * 2.0e+00
      * ( tx1 * ( c34 - c1345 )
        + ty1 * ( c34 - c1345 )
	  + tz1 * ( r43*c34 - c1345 ) ) * tmp2 * u0(4);
      d(5,5,i,j) = 1.0e+00
        + dt * 2.0e+00 * ( tx1 + ty1 + tz1 ) * c1345 * tmp1
        + dt * 2.0e+00 * (  tx1 * dx5
                         +  ty1 * dy5
			    +  tz1 * dz5 );

/* c--------------------------------------------------------------------- */
/* c   form the first block sub-diagonal */
/* c--------------------------------------------------------------------- */
      tmp1 = 1.0e+00 / ux(1);
      tmp2 = tmp1 * tmp1;
      tmp3 = tmp1 * tmp2;

      a(1,1,i,j) = - dt * tx1 * dx1;
      a(1,2,i,j) =   dt * tx2;
      a(1,3,i,j) =   0.0e+00;
      a(1,4,i,j) =   0.0e+00;
      a(1,5,i,j) =   0.0e+00;
      a(2,1,i,j) =  dt * tx2
               * ( - POW2( ux(2) * tmp1 )
          + c2 * 0.50e+00 * (  ux(2) * ux(2)
                             + ux(3) * ux(3)
                             + ux(4) * ux(4) ) * tmp2 )
	- dt * tx1 * ( - r43 * c34 * tmp2 * ux(2) );
      a(2,2,i,j) =  dt * tx2
               * ( ( 2.0e+00 - c2 ) * ( ux(2) * tmp1 ) )
               - dt * tx1 * ( r43 * c34 * tmp1 )
	- dt * tx1 * dx2;
      a(2,3,i,j) =  dt * tx2
	* ( - c2 * ( ux(3) * tmp1 ) );
      a(2,4,i,j) =  dt * tx2
	* ( - c2 * ( ux(4) * tmp1 ) );
      a(2,5,i,j) =  dt * tx2 * c2;

      a(3,1,i,j) =  dt * tx2
                   * ( - ( ux(2) * ux(3) ) * tmp2 )
	- dt * tx1 * ( - c34 * tmp2 * ux(3) );
      a(3,2,i,j) =  dt * tx2 * ( ux(3) * tmp1 );
      a(3,3,i,j) =  dt * tx2 * ( ux(2) * tmp1 )
               - dt * tx1 * ( c34 * tmp1 )
	- dt * tx1 * dx3;
      a(3,4,i,j) = 0.0e+00;
      a(3,5,i,j) = 0.0e+00;

      a(4,1,i,j) = dt * tx2
               * ( - ( ux(2)*ux(4) ) * tmp2 )
	- dt * tx1 * ( - c34 * tmp2 * ux(4) );
      a(4,2,i,j) = dt * tx2 * ( ux(4) * tmp1 );
      a(4,3,i,j) = 0.0e+00;
      a(4,4,i,j) = dt * tx2 * ( ux(2) * tmp1 )
               - dt * tx1 * ( c34 * tmp1 )
	- dt * tx1 * dx4;
      a(4,5,i,j) = 0.0e+00;

      a(5,1,i,j) = dt * tx2
               * ( ( c2 * (  ux(2) * ux(2)
                           + ux(3) * ux(3)
                           + ux(4) * ux(4) ) * tmp2
                   - c1 * ( ux(5) * tmp1 ) )
               * ( ux(2) * tmp1 ) )
               - dt * tx1
               * ( - ( r43*c34 - c1345 ) * tmp3 * ( POW2(ux(2)) )
                   - (     c34 - c1345 ) * tmp3 * ( POW2(ux(3)) )
                   - (     c34 - c1345 ) * tmp3 * ( POW2(ux(4)) )
                   - c1345 * tmp2 * ux(5) );
      a(5,2,i,j) = dt * tx2
               * ( c1 * ( ux(5) * tmp1 )
                  - 0.50e+00 * c2
                  * ( (  3.0e+00*ux(2)*ux(2)
                       + ux(3)*ux(3)
                       + ux(4)*ux(4) ) * tmp2 ) )
                - dt * tx1
	* ( r43*c34 - c1345 ) * tmp2 * ux(2);
      a(5,3,i,j) = dt * tx2
                * ( - c2 * ( ux(3)*ux(2) ) * tmp2 )
                - dt * tx1
	* (  c34 - c1345 ) * tmp2 * ux(3);
      a(5,4,i,j) = dt * tx2
                * ( - c2 * ( ux(4)*ux(2) ) * tmp2 )
                - dt * tx1
	* (  c34 - c1345 ) * tmp2 * ux(4);
      a(5,5,i,j) = dt * tx2
                * ( c1 * ( ux(2) * tmp1 ) )
                - dt * tx1 * c1345 * tmp1
	- dt * tx1 * dx5;

/* c--------------------------------------------------------------------- */
/* c   form the second block sub-diagonal */
/* c--------------------------------------------------------------------- */
      tmp1 = 1.0e+00 / uy(1);
      tmp2 = tmp1 * tmp1;
      tmp3 = tmp1 * tmp2;

      b(1,1,i,j) = - dt * ty1 * dy1;
      b(1,2,i,j) =   0.0e+00;
      b(1,3,i,j) =  dt * ty2;
      b(1,4,i,j) =   0.0e+00;
      b(1,5,i,j) =   0.0e+00;

      b(2,1,i,j) =  dt * ty2
                * ( - ( uy(2)*uy(3) ) * tmp2 )
	- dt * ty1 * ( - c34 * tmp2 * uy(2) );
      b(2,2,i,j) =  dt * ty2 * ( uy(3) * tmp1 )
               - dt * ty1 * ( c34 * tmp1 )
	- dt * ty1 * dy2;
      b(2,3,i,j) =  dt * ty2 * ( uy(2) * tmp1 );
      b(2,4,i,j) = 0.0e+00;
      b(2,5,i,j) = 0.0e+00;

      b(3,1,i,j) =  dt * ty2
                * ( - POW2( uy(3) * tmp1 )
           + 0.50e+00 * c2 * ( (  uy(2) * uy(2)
                                + uy(3) * uy(3)
                                + uy(4) * uy(4) )
                               * tmp2 ) )
	- dt * ty1 * ( - r43 * c34 * tmp2 * uy(3) );
      b(3,2,i,j) =  dt * ty2
	* ( - c2 * ( uy(2) * tmp1 ) );
      b(3,3,i,j) =  dt * ty2 * ( ( 2.0e+00 - c2 )
                        * ( uy(3) * tmp1 ) )
            - dt * ty1 * ( r43 * c34 * tmp1 )
	- dt * ty1 * dy3;
      b(3,4,i,j) =  dt * ty2
	* ( - c2 * ( uy(4) * tmp1 ) );
      b(3,5,i,j) =  dt * ty2 * c2;

      b(4,1,i,j) =  dt * ty2
                   * ( - ( uy(3)*uy(4) ) * tmp2 )
	- dt * ty1 * ( - c34 * tmp2 * uy(4) );
      b(4,2,i,j) = 0.0e+00;
      b(4,3,i,j) =  dt * ty2 * ( uy(4) * tmp1 );
      b(4,4,i,j) =  dt * ty2 * ( uy(3) * tmp1 )
                             - dt * ty1 * ( c34 * tmp1 )
	- dt * ty1 * dy4;
      b(4,5,i,j) = 0.0e+00;

      b(5,1,i,j) =  dt * ty2
               * ( ( c2 * (  uy(2) * uy(2)
                           + uy(3) * uy(3)
                           + uy(4) * uy(4) ) * tmp2
                    - c1 * ( uy(5) * tmp1 ) )
               * ( uy(3) * tmp1 ) )
               - dt * ty1
               * ( - (     c34 - c1345 )*tmp3*( POW2(uy(2)) )
                   - ( r43*c34 - c1345 )*tmp3*( POW2(uy(3)) )
                   - (     c34 - c1345 )*tmp3*( POW2(uy(4)) )
                   - c1345*tmp2*uy(5) );
      b(5,2,i,j) =  dt * ty2
               * ( - c2 * ( uy(2)*uy(3) ) * tmp2 )
               - dt * ty1
	* ( c34 - c1345 ) * tmp2 * uy(2);
      b(5,3,i,j) =  dt * ty2
               * ( c1 * ( uy(5) * tmp1 )
               - 0.50e+00 * c2
               * ( (  uy(2)*uy(2)
                    + 3.0e+00 * uy(3)*uy(3)
                    + uy(4)*uy(4) ) * tmp2 ) )
               - dt * ty1
	* ( r43*c34 - c1345 ) * tmp2 * uy(3);
      b(5,4,i,j) =  dt * ty2
               * ( - c2 * ( uy(3)*uy(4) ) * tmp2 )
	- dt * ty1 * ( c34 - c1345 ) * tmp2 * uy(4);
      b(5,5,i,j) =  dt * ty2
               * ( c1 * ( uy(3) * tmp1 ) )
               - dt * ty1 * c1345 * tmp1
	- dt * ty1 * dy5;

/* c--------------------------------------------------------------------- */
/* c   form the third block sub-diagonal */
/* c--------------------------------------------------------------------- */
      tmp1 = 1.0e+00 / uz(1);
      tmp2 = tmp1 * tmp1;
      tmp3 = tmp1 * tmp2;

      c(1,1,i,j) = - dt * tz1 * dz1;
      c(1,2,i,j) =   0.0e+00;
      c(1,3,i,j) =   0.0e+00;
      c(1,4,i,j) = dt * tz2;
      c(1,5,i,j) =   0.0e+00;

      c(2,1,i,j) = dt * tz2
                * ( - ( uz(2)*uz(4) ) * tmp2 )
	- dt * tz1 * ( - c34 * tmp2 * uz(2) );
      c(2,2,i,j) = dt * tz2 * ( uz(4) * tmp1 )
                - dt * tz1 * c34 * tmp1
	- dt * tz1 * dz2;
      c(2,3,i,j) = 0.0e+00;
      c(2,4,i,j) = dt * tz2 * ( uz(2) * tmp1 );
      c(2,5,i,j) = 0.0e+00;

      c(3,1,i,j) = dt * tz2
                * ( - ( uz(3)*uz(4) ) * tmp2 )
	- dt * tz1 * ( - c34 * tmp2 * uz(3) );
      c(3,2,i,j) = 0.0e+00;
      c(3,3,i,j) = dt * tz2 * ( uz(4) * tmp1 )
                - dt * tz1 * ( c34 * tmp1 )
	- dt * tz1 * dz3;
      c(3,4,i,j) = dt * tz2 * ( uz(3) * tmp1 );
      c(3,5,i,j) = 0.0e+00;

      c(4,1,i,j) = dt * tz2
             * ( - POW2( uz(4) * tmp1 )
                 + 0.50e+00 * c2
                 * ( ( uz(2) * uz(2)
                     + uz(3) * uz(3)
                     + uz(4) * uz(4) ) * tmp2 ) )
	- dt * tz1 * ( - r43 * c34 * tmp2 * uz(4) );
      c(4,2,i,j) = dt * tz2
	* ( - c2 * ( uz(2) * tmp1 ) );
      c(4,3,i,j) = dt * tz2
	* ( - c2 * ( uz(3) * tmp1 ) );
      c(4,4,i,j) = dt * tz2 * ( 2.0e+00 - c2 )
                  * ( uz(4) * tmp1 )
                  - dt * tz1 * ( r43 * c34 * tmp1 )
	- dt * tz1 * dz4;
      c(4,5,i,j) = dt * tz2 * c2;

      c(5,1,i,j) = dt * tz2
          * ( ( c2 * (  uz(2) * uz(2)
                      + uz(3) * uz(3)
                      + uz(4) * uz(4) ) * tmp2
            - c1 * ( uz(5) * tmp1 ) )
                 * ( uz(4) * tmp1 ) )
            - dt * tz1
            * ( - ( c34 - c1345 ) * tmp3 * ( POW2(uz(2)) )
                - ( c34 - c1345 ) * tmp3 * ( POW2(uz(3)) )
                - ( r43*c34 - c1345 )* tmp3 * ( POW2(uz(4)) )
		- c1345 * tmp2 * uz(5) );

      c(5,2,i,j) = dt * tz2
            * ( - c2 * ( uz(2)*uz(4) ) * tmp2 )
	- dt * tz1 * ( c34 - c1345 ) * tmp2 * uz(2);
      c(5,3,i,j) = dt * tz2
            * ( - c2 * ( uz(3)*uz(4) ) * tmp2 )
	- dt * tz1 * ( c34 - c1345 ) * tmp2 * uz(3);
      c(5,4,i,j) = dt * tz2
            * ( c1 * ( uz(5) * tmp1 )
            - 0.50e+00 * c2
            * ( (  uz(2)*uz(2)
                 + uz(3)*uz(3)
                 + 3.0e+00*uz(4)*uz(4) ) * tmp2 ) )
	- dt * tz1 * ( r43*c34 - c1345 ) * tmp2 * uz(4);
      c(5,5,i,j) = dt * tz2
            * ( c1 * ( uz(4) * tmp1 ) )
            - dt * tz1 * c1345 * tmp1
	- dt * tz1 * dz5;
    } /* i */
  } /* j */
}
/* -------------------------------------------------------------------------- */
