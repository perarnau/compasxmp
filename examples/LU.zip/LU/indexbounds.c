#include "applu.h"
#include "proto.h"
/* -------------------------------------------------------------------------- */
typedef struct {
  int updown, updowne, topseg, botseg;
  int section1, section2, section3;
  int xsize, ysize, zsize;
  int first, last;
} LoopControlStruct;
/* -------------------------------------------------------------------------- */
void InitSectionsN()
{
 xsize = isiz1;
 ysize = isiz2;
 zsize = isiz3;
               
 section1 = xsize + 2;
 section2 = xsize + ysize - 1;
 section3 = xsize + ysize + zsize - 3;
}
/* -------------------------------------------------------------------------- */
static void InitLoopBoundsLocalN( int k, LoopControlStruct *LC /* inout */)
{
  LC->section1 = section1;
  LC->section2 = section2;
  LC->section3 = section3;
  LC->xsize = xsize;
  LC->ysize = ysize;
  LC->zsize = zsize;
  LC->updown = 0;
  LC->updowne = 0;
  LC->topseg = 0;
  LC->botseg = 0;

  if ( k <= section1 ){
    jfirst = 2;
    jlast = k-4;
  }else if ( k <= section2 ){
    jfirst = 2;
    jlast = ysize-1;
  }else{
    jfirst = k-section2+1;
    jlast = xsize-1;
  } /* endif */
}
/* -------------------------------------------------------------------------- */
static void GetIBoundsLocalN( int j, int k, LoopControlStruct *LC /* inout */)
{
  if ( k <= LC->section1){
    LC->first = 2;
    LC->last = jlast + 2 - j;
  }else if ( k <= LC->section2){
    if ( j < k - LC->xsize ){
      LC->first = k - j - LC->xsize + 1;
      LC->last = LC->zsize - 1;
    }else{
      LC->first = 2;
      LC->last =  k - j - 2;
    } /* endif */
  }else{
    LC->first = k - j - LC->xsize + 1;
    LC->last = LC->xsize - 1;
  } /* endif */
}
/* -------------------------------------------------------------------------- */
void SetLoopBounds()
{
  int sumdim, k, j;
  LoopControlStruct loopControl;

  sumdim = isiz1+isiz2+isiz3-3;
  for (k =6; k <=sumdim; k ++){
    InitLoopBoundsLocalN( k, &loopControl /* inout */);
    jlow(k) = jfirst;
    jhigh(k) = jlast;

    for (j=jfirst; j<=jlast ; j++){
      GetIBoundsLocalN( j, k, &loopControl /* inout */);
      ilow(k,j) = loopControl.first;
      ihigh(k,j) = loopControl.last;
    } /* j */

  } /* k */
}
/* -------------------------------------------------------------------------- */
