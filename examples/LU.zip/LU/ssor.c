#include "applu.h"
#include "proto.h"
/* -------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------- */
void ssor()
{
/* c--------------------------------------------------------------------- */
/* c   to perform pseudo-time stepping SSOR iterations */
/* c   for five nonlinear pde's. */
/* c--------------------------------------------------------------------- */
  int i, j, k, m, n, istep, l, lst, lend;
  double tmp;
  double _delunm[5 +1];

/* c--------------------------------------------------------------------- */
/* c   begin pseudo-time stepping iterations */
/* c--------------------------------------------------------------------- */
  tmp = 1.0e+00 / ( omega * ( 2.0e+00 - omega ) );
  lst = ist + jst + 2;
  lend = iend + jend + nz - 1;

/* c--------------------------------------------------------------------- */
/* c   initialize a,b,c,d to zero (guarantees that page tables have been */
/* c   formed, if applicable on given architecture, before timestepping). */
/* c--------------------------------------------------------------------- */
#pragma xmp loop on ProjArea(j)
  for (j=1; j<=isiz2; j++){
    for (i=1; i<=isiz1; i++){
      for (n=1; n<=5; n++){
	for (m=1; m<=5; m++){
	  a(m,n,i,j) = 0.0;
	  b(m,n,i,j) = 0.0;
	  c(m,n,i,j) = 0.0;
	  d(m,n,i,j) = 0.0;
	} /* m */
      } /* n */
    } /* i */
  } /* j */
  for (i =1; i <=t_last; i ++){
    timer_clear(i);
  }

  rhs();

/* c--------------------------------------------------------------------- */
/* c   compute the L2 norms of newton iteration residuals */
/* c--------------------------------------------------------------------- */
//  l2norm( isiz1, isiz2, isiz3, nx0, ny0, nz0, ist, iend, jst, jend, _rsd, _rsdnm );
  l2norm( nx0, ny0, nz0, ist, iend, jst, jend, _rsd, _rsdnm ); 

  for (i =1; i <=t_last; i ++){
    timer_clear(i);
  }
  timer_start(t_total);

  InitSectionsN();
  SetLoopBounds();

/* c--------------------------------------------------------------------- */
/* c   the timestep loop */
/* c--------------------------------------------------------------------- */
  for (istep =1; istep <=itmax; istep ++){
    if (mod(istep, 20) == 0 || istep == itmax || istep == 1){
#pragma xmp task on ProjArea(0)
      printf(" Time step %4d\n", istep);
    } /* endif */
 
/* c--------------------------------------------------------------------- */
/* c   perform SSOR iteration */
/* c--------------------------------------------------------------------- */
    if (timeron) timer_start(t_rhs);
    for (k=2; k<=nz-1; k++){
#pragma xmp loop(j) on ProjArea(j)
      for (j=jst; j<=jend; j++){
	for (i=ist; i<=iend; i++){
	  for (m =1; m <=5; m ++){
	    rsd(m,i,j,k) = dt * rsd(m,i,j,k);
	  } /* m */
	} /* i */
      } /* j */
    } /* k */ 

    if (timeron) timer_stop(t_rhs);
    for (l =lst; l <=lend; l ++){
/* c--------------------------------------------------------------------- */
/* c   form the lower triangular part of the jacobian matrix */
/* c--------------------------------------------------------------------- */
      if (timeron) timer_start(t_jacld);
      jacld(l);
      if (timeron) timer_stop(t_jacld);
 
/* c--------------------------------------------------------------------- */
/* c   perform the lower triangular solution */
/* c--------------------------------------------------------------------- */

      if (timeron) timer_start(t_blts);
      //      blts( isiz1, isiz2, isiz3, l, omega, _rsd, _a, _b, _c, _d);
      blts( l, omega, _rsd, _a, _b, _c, _d);
      if (timeron) timer_stop(t_blts);
    } /* l */

    for (l =lend; l >=lst; l --){
/* c--------------------------------------------------------------------- */
/* c   form the strictly upper triangular part of the jacobian matrix */
/* c--------------------------------------------------------------------- */

      if (timeron) timer_start(t_jacu);
      jacu(l);
      if (timeron) timer_stop(t_jacu);

/* c--------------------------------------------------------------------- */
/* c   perform the upper triangular solution */
/* c--------------------------------------------------------------------- */
      if (timeron) timer_start(t_buts);
      //      buts( isiz1, isiz2, isiz3, l, omega, _rsd, _d, _a, _b, _c);
      buts( l, omega, _rsd, _d, _a, _b, _c);
      if (timeron) timer_stop(t_buts);
    } /* l */

/* c--------------------------------------------------------------------- */
/* c   update the variables */
/* c--------------------------------------------------------------------- */

    if (timeron) timer_start(t_add);
#pragma xmp loop(j) on ProjArea(j)
    for (j =jst; j <=jend; j ++){
      for (k =2; k <=nz-1; k ++){
	for (i =ist; i <=iend; i ++){
	  for (m =1; m <=5; m ++){
	    u( m, i, j, k ) = u( m, i, j, k ) + tmp * rsd( m, i, j, k );
	  } /* m */
	} /* i */
      } /* k */
    } /* j */
    if (timeron) timer_stop(t_add);

/* c--------------------------------------------------------------------- */
/* c   compute the max-norms of newton iteration corrections */
/* c--------------------------------------------------------------------- */
    if ( mod ( istep, inorm ) == 0 ){
      if (timeron) timer_start(t_l2norm);
      //      l2norm( isiz1, isiz2, isiz3, nx0, ny0, nz0, ist, iend, jst, jend, _rsd, _delunm );
      l2norm( nx0, ny0, nz0, ist, iend, jst, jend, _rsd, _delunm );
      if (timeron) timer_stop(t_l2norm);
         } /* endif */
 
/* c--------------------------------------------------------------------- */
/* c   compute the steady-state residuals */
/* c--------------------------------------------------------------------- */
    if (timeron) timer_start(t_rhs);
    rhs();
    if (timeron) timer_stop(t_rhs);
 
/* c--------------------------------------------------------------------- */
/* c   compute the max-norms of newton iteration residuals */
/* c--------------------------------------------------------------------- */
    if ( ( mod ( istep, inorm ) == 0 ) || ( istep == itmax ) ){
      if (timeron) timer_start(t_l2norm);
      //      l2norm( isiz1, isiz2, isiz3, nx0, ny0, nz0, ist, iend, jst, jend, _rsd, _rsdnm );
      l2norm( nx0, ny0, nz0, ist, iend, jst, jend, _rsd, _rsdnm );
      if (timeron) timer_stop(t_l2norm);
         } /* endif */

/* c--------------------------------------------------------------------- */
/* c   check the newton-iteration residuals against the tolerance levels */
/* c--------------------------------------------------------------------- */
    if ( ( rsdnm(1) < tolrsd(1) ) &&
	 ( rsdnm(2) < tolrsd(2) ) &&
	 ( rsdnm(3) < tolrsd(3) ) &&
	 ( rsdnm(4) < tolrsd(4) ) &&
	 ( rsdnm(5) < tolrsd(5) ) ){
      return;
    } /* endif */
  } /* istep */
 
  timer_stop(t_total);
  maxtime = timer_read(t_total);
  return;
}
/* -------------------------------------------------------------------------- */
