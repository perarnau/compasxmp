#include "applu.h"
#include "proto.h"
#ifdef _XCALABLEMP
#include "xmp.h"
#endif
/* -------------------------------------------------------------------------- */
void pintgr()
{
  int i, j, k;
  int ibeg, ifin, ifin1;
  int jbeg, jfin, jfin1;
  double frc1, frc2, frc3;
  double _phi1_local[isiz3+1 +1][isiz2+1 +1];
  double _phi2_local[isiz3+1 +1][isiz2+1 +1];
#define  phi1_x(a,b)      _phi1_x[b][a]
#define  phi2_x(a,b)      _phi2_x[b][a]
#define  phi1_y(a,b)      _phi1_y[b][a]
#define  phi2_y(a,b)      _phi2_y[b][a]
#define  phi1_local(a,b)  _phi1_local[b][a]
#define  phi2_local(a,b)  _phi2_local[b][a]

/* c--------------------------------------------------------------------- */
/* c   set up the sub-domains for integeration in each processor */
/* c--------------------------------------------------------------------- */
  ibeg = ii1;
  ifin = ii2;
  jbeg = ji1;
  jfin = ji2;
  ifin1 = ifin - 1;
  jfin1 = jfin - 1;

/* c--------------------------------------------------------------------- */
/* c   initialize */
/* c--------------------------------------------------------------------- */
#if 0 /* ORIGINAL */
  for (i = 0; i <=isiz2+1; i ++){
    for (k = 0; k <=isiz3+1; k ++){
      phi1_x(i,k) = 0.0;
      phi2_x(i,k) = 0.0;
    } /* k */
  } /* i */
#else
#pragma xmp loop(k) on ProjArea(k)
  for (k = 0; k <=isiz3+1; k ++){
    for (i = 0; i <=isiz2+1; i ++){
      phi1_x(i,k) = 0.0;
      phi2_x(i,k) = 0.0;
    } /* i */
  } /* k */
#endif

#pragma xmp loop(j) on ProjArea(j)
  for (j = jbeg; j <=jfin; j ++){
    for (i = ibeg; i <=ifin; i ++){
      k = ki1;
      phi1_x(i,j) = c2*( u(5,i,j,k) - 0.50 * (  POW2(u(2,i,j,k))
		 + POW2(u(3,i,j,k)) + POW2(u(4,i,j,k)) ) / u(1,i,j,k) );

      k = ki2;
      phi2_x(i,j) = c2*( u(5,i,j,k) - 0.50 * (  POW2(u(2,i,j,k))
		 + POW2(u(3,i,j,k)) + POW2(u(4,i,j,k)) ) / u(1,i,j,k) );
    } /* i */
  } /* j */

  frc1 = 0.0;
#pragma xmp reflect _phi1_x
#pragma xmp reflect _phi2_x
#pragma xmp loop(j) on ProjArea(j) reduction(+:frc1)
  for (j = jbeg; j <=jfin1; j ++){
    for (i = ibeg; i <= ifin1; i ++){
      frc1 = frc1 + (  phi1_x(i,j) + phi1_x(i+1,j) + phi1_x(i,j+1) + phi1_x(i+1,j+1)
		       + phi2_x(i,j) + phi2_x(i+1,j) + phi2_x(i,j+1) + phi2_x(i+1,j+1) );
    } /* i */
  } /* j */
  frc1 = dxi * deta * frc1;

/* c--------------------------------------------------------------------- */
/* c   initialize */
/* c--------------------------------------------------------------------- */
#if 0 /* ORIGINAL */
  for (i = 0; i <=isiz2+1; i ++){
    for (k = 0; k <=isiz3+1; k ++){
      phi1_local(i,k) = 0.0;
      phi2_local(i,k) = 0.0;
    } /* k */
  } /* i */
#else
  for (k = 0; k <=isiz3+1; k ++){
    for (i = 0; i <=isiz2+1; i ++){
      phi1_local(i,k) = 0.0;
      phi2_local(i,k) = 0.0;
    } /* i */
  } /* k */
#endif

  if (jbeg == ji1){
#pragma xmp task on ProjArea(jbeg)
    {
      for (k = ki1; k <= ki2; k ++){
	for (i = ibeg; i <= ifin; i ++){
	  phi1_local(i,k) = c2*(  u(5,i,jbeg,k) - 0.50 * (  POW2(u(2,i,jbeg,k))
			       + POW2(u(3,i,jbeg,k)) + POW2(u(4,i,jbeg,k)) ) / u(1,i,jbeg,k) );
	} /* i */
      } /* k */
    } /* task */
  } /* end if */

  if (jfin == ji2){
#pragma xmp task on ProjArea(jfin)
    {
      for (k = ki1; k <= ki2; k ++){
	for (i = ibeg; i <= ifin; i ++){
	  phi2_local(i,k) = c2*(  u(5,i,jfin,k) - 0.50 * (  POW2(u(2,i,jfin,k))
			  + POW2(u(3,i,jfin,k)) + POW2(u(4,i,jfin,k)) ) / u(1,i,jfin,k) );
	} /* i */
      } /* k */
    } /* task */
  } /* end if */

  frc2 = 0.0;
  for (k = ki1; k <= ki2-1; k ++){
    for (i = ibeg; i <= ifin1; i ++){
      frc2 = frc2 + (  phi1_local(i,k) + phi1_local(i+1,k) + phi1_local(i,k+1) + phi1_local(i+1,k+1)
		       + phi2_local(i,k) + phi2_local(i+1,k) + phi2_local(i,k+1) + phi2_local(i+1,k+1) );
    } /* i */
  } /* k */
  frc2 = dxi * dzeta * frc2;
#pragma xmp reduction(+:frc2)

/* c--------------------------------------------------------------------- */
/* c   initialize */
/* c--------------------------------------------------------------------- */
#if 0 /* ORIGINAL */
  for (i = 0; i <=isiz2+1; i ++){
    for (k = 0; k <=isiz3+1; k ++){
      phi1_y(i,k) = 0.0;
      phi2_y(i,k) = 0.0;
    } /* k */
  } /* i */
#else
  for (k = 0; k <=isiz3+1; k ++){
#pragma xmp loop(i) on ProjArea(i)
    for (i = 0; i <=isiz2+1; i ++){
      phi1_y(i,k) = 0.0;
      phi2_y(i,k) = 0.0;
    } /* i */
  } /* k */
#endif
  if (ibeg == ii1){
    for (k = ki1; k <= ki2; k ++){
#pragma xmp loop(j) on ProjArea(j)
      for (j = jbeg; j <= jfin; j ++){
	  phi1_y(j,k) = c2*( u(5,ibeg,j,k) - 0.50 * ( POW2(u(2,ibeg,j,k))
		      + POW2(u(3,ibeg,j,k)) + POW2(u(4,ibeg,j,k)) ) / u(1,ibeg,j,k) );
      } /* j */
    } /* k */
  } /* end if */

  if (ifin == ii2){
    for (k = ki1; k <= ki2; k ++){
#pragma xmp loop(j) on ProjArea(j)
      for (j = jbeg; j <= jfin; j ++){
	  phi2_y(j,k) = c2*( u(5,ifin,j,k) - 0.50 * (  POW2(u(2,ifin,j,k))
			 + POW2(u(3,ifin,j,k)) + POW2(u(4,ifin,j,k)) ) / u(1,ifin,j,k) );
      } /* j */
    } /* k */
  } /* end if */

#pragma xmp reflect _phi1_y
#pragma xmp reflect _phi2_y
  frc3 = 0.0;
  for (k = ki1; k <= ki2-1; k ++){
#pragma xmp loop(j) on ProjArea(j) reduction(+:frc3)
    for (j = jbeg; j <= jfin1; j ++){
      frc3 = frc3 + ( phi1_y(j,k) + phi1_y(j+1,k) + phi1_y(j,k+1) + phi1_y(j+1,k+1)
                      + phi2_y(j,k) + phi2_y(j+1,k) + phi2_y(j,k+1) + phi2_y(j+1,k+1) );
    } /* j */
  } /* k */

  frc3 = deta * dzeta * frc3;
  frc = 0.25 * ( frc1 + frc2 + frc3 );
}
/* -------------------------------------------------------------------------- */
