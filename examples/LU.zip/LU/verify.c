#include "applu.h"
#include "proto.h"
/* -------------------------------------------------------------------------- */
#define     xcr(m)     _xcr[m]
#define     xce(m)     _xce[m]
#define  xcrref(m)  _xcrref[m]
#define  xceref(m)  _xceref[m]
#define  xcrdif(m)  _xcrdif[m]
#define  xcedif(m)  _xcedif[m]

void verify(double _xcr[5 +1], double _xce[5 +1], double xci, char *class, int *verified)
{
/* c--------------------------------------------------------------------- */
/* c  verification routine                          */
/* c--------------------------------------------------------------------- */
  double _xcrref[5 +1], _xceref[5 +1], xciref;
  double _xcrdif[5 +1], _xcedif[5 +1], xcidif;
  double epsilon, dtref = 0.0;
  int m;
/* c--------------------------------------------------------------------- */
/* c   tolerance level */
/* c--------------------------------------------------------------------- */
  epsilon = 1.0e-08;

  *class = 'U';
  *verified = TRUE;

  for (m = 1; m <=5; m ++){
    xcrref(m) = 1.0;
    xceref(m) = 1.0;
  }
  xciref = 1.0;

  if ( (nx0  == 12     ) && 
       (ny0  == 12     ) &&
       (nz0  == 12     ) &&
       (itmax   == 50    )){

    *class = 'S';
    dtref = 5.0e-1;
/* c--------------------------------------------------------------------- */
/* c   Reference values of RMS-norms of residual, for the (12X12X12) grid, */
/* c   after 50 time steps, with  DT = 5.0d-01 */
/* c--------------------------------------------------------------------- */
    xcrref(1) = 1.6196343210976702e-02;
    xcrref(2) = 2.1976745164821318e-03;
    xcrref(3) = 1.5179927653399185e-03;
    xcrref(4) = 1.5029584435994323e-03;
    xcrref(5) = 3.4264073155896461e-02;
/* c--------------------------------------------------------------------- */
/* c   Reference values of RMS-norms of solution error, for the (12X12X12) grid, */
/* c   after 50 time steps, with  DT = 5.0d-01 */
/* c--------------------------------------------------------------------- */
    xceref(1) = 6.4223319957960924e-04;
    xceref(2) = 8.4144342047347926e-05;
    xceref(3) = 5.8588269616485186e-05;
    xceref(4) = 5.8474222595157350e-05;
    xceref(5) = 1.3103347914111294e-03;
/* c--------------------------------------------------------------------- */
/* c   Reference value of surface integral, for the (12X12X12) grid, */
/* c   after 50 time steps, with DT = 5.0d-01 */
/* c--------------------------------------------------------------------- */
    xciref = 7.8418928865937083e+00;

  }else if ( (nx0 == 33) && 
	     (ny0 == 33) &&
	     (nz0 == 33) &&
	     (itmax == 300) ){

    *class = 'W';   /* SPEC95fp size */
    dtref = 1.5e-3;
/* c--------------------------------------------------------------------- */
/* c   Reference values of RMS-norms of residual, for the (33x33x33) grid, */
/* c   after 300 time steps, with  DT = 1.5d-3 */
/* c--------------------------------------------------------------------- */
    xcrref(1) =   0.1236511638192e+02;
    xcrref(2) =   0.1317228477799e+01;
    xcrref(3) =   0.2550120713095e+01;
    xcrref(4) =   0.2326187750252e+01;
    xcrref(5) =   0.2826799444189e+02;
/* c--------------------------------------------------------------------- */
/* c   Reference values of RMS-norms of solution error, for the (33X33X33) grid, */
/* c--------------------------------------------------------------------- */
    xceref(1) =   0.4867877144216e+00;
    xceref(2) =   0.5064652880982e-01;
    xceref(3) =   0.9281818101960e-01;
    xceref(4) =   0.8570126542733e-01;
    xceref(5) =   0.1084277417792e+01;
/* c--------------------------------------------------------------------- */
/* c   Reference value of surface integral, for the (33X33X33) grid, */
/* c   after 300 time steps, with  DT = 1.5d-3 */
/* c--------------------------------------------------------------------- */
    xciref    =   0.1161399311023e+02;

  }else if ( (nx0 == 64) && 
	     (ny0 == 64) &&
	     (nz0 == 64) &&
	     (itmax == 250) ){

    *class = 'A';
    dtref = 2.0e+0;
/* c--------------------------------------------------------------------- */
/* c   Reference values of RMS-norms of residual, for the (64X64X64) grid, */
/* c   after 250 time steps, with  DT = 2.0d+00 */
/* c--------------------------------------------------------------------- */
    xcrref(1) = 7.7902107606689367e+02;
    xcrref(2) = 6.3402765259692870e+01;
    xcrref(3) = 1.9499249727292479e+02;
    xcrref(4) = 1.7845301160418537e+02;
    xcrref(5) = 1.8384760349464247e+03;
/* c--------------------------------------------------------------------- */
/* c   Reference values of RMS-norms of solution error, for the (64X64X64) grid, */
/* c   after 250 time steps, with  DT = 2.0d+00 */
/* c--------------------------------------------------------------------- */
    xceref(1) = 2.9964085685471943e+01;
    xceref(2) = 2.8194576365003349e+00;
    xceref(3) = 7.3473412698774742e+00;
    xceref(4) = 6.7139225687777051e+00;
    xceref(5) = 7.0715315688392578e+01;
/* c--------------------------------------------------------------------- */
/* c   Reference value of surface integral, for the (64X64X64) grid, */
/* c   after 250 time steps, with DT = 2.0d+00 */
/* c--------------------------------------------------------------------- */
    xciref = 2.6030925604886277e+01;

  }else if ( (nx0 == 102) && 
	     (ny0 == 102) &&
	     (nz0 == 102) &&
	     (itmax == 250) ){

    *class = 'B';
    dtref = 2.0e+0;
/* c--------------------------------------------------------------------- */
/* c   Reference values of RMS-norms of residual, for the (102X102X102) grid, */
/* c   after 250 time steps, with  DT = 2.0d+00 */
/* c--------------------------------------------------------------------- */
    xcrref(1) = 3.5532672969982736e+03;
    xcrref(2) = 2.6214750795310692e+02;
    xcrref(3) = 8.8333721850952190e+02;
    xcrref(4) = 7.7812774739425265e+02;
    xcrref(5) = 7.3087969592545314e+03;
/* c--------------------------------------------------------------------- */
/* c   Reference values of RMS-norms of solution error, for the (102X102X102)  */
/* c   grid, after 250 time steps, with  DT = 2.0d+00 */
/* c--------------------------------------------------------------------- */
    xceref(1) = 1.1401176380212709e+02;
    xceref(2) = 8.1098963655421574e+00;
    xceref(3) = 2.8480597317698308e+01;
    xceref(4) = 2.5905394567832939e+01;
    xceref(5) = 2.6054907504857413e+02;
/* c--------------------------------------------------------------------- */
/* c   Reference value of surface integral, for the (102X102X102) grid, */
/* c   after 250 time steps, with DT = 2.0d+00 */
/* c--------------------------------------------------------------------- */
    xciref = 4.7887162703308227e+01;

  }else if ( (nx0 == 162) && 
	     (ny0 == 162) &&
	     (nz0 == 162) &&
	     (itmax == 250) ){

    *class = 'C';
    dtref = 2.0e+0;
/* c--------------------------------------------------------------------- */
/* c   Reference values of RMS-norms of residual, for the (162X162X162) grid, */
/* c   after 250 time steps, with  DT = 2.0d+00 */
/* c--------------------------------------------------------------------- */
    xcrref(1) = 1.03766980323537846e+04;
    xcrref(2) = 8.92212458801008552e+02;
    xcrref(3) = 2.56238814582660871e+03;
    xcrref(4) = 2.19194343857831427e+03;
    xcrref(5) = 1.78078057261061185e+04;
/* c--------------------------------------------------------------------- */
/* c   Reference values of RMS-norms of solution error, for the (162X162X162)  */
/* c   grid, after 250 time steps, with  DT = 2.0d+00 */
/* c--------------------------------------------------------------------- */
    xceref(1) = 2.15986399716949279e+02;
    xceref(2) = 1.55789559239863600e+01;
    xceref(3) = 5.41318863077207766e+01;
    xceref(4) = 4.82262643154045421e+01;
    xceref(5) = 4.55902910043250358e+02;
/* c--------------------------------------------------------------------- */
/* c   Reference value of surface integral, for the (162X162X162) grid, */
/* c   after 250 time steps, with DT = 2.0d+00 */
/* c--------------------------------------------------------------------- */
    xciref = 6.66404553572181300e+01;

  }else if ( (nx0 == 408) && 
	     (ny0 == 408) &&
	     (nz0 == 408) &&
	     (itmax == 300) ){

    *class = 'D';
    dtref = 1.0e+0;
/* c--------------------------------------------------------------------- */
/* c   Reference values of RMS-norms of residual, for the (408X408X408) grid, */
/* c   after 300 time steps, with  DT = 1.0d+00 */
/* c--------------------------------------------------------------------- */
    xcrref(1) = 0.4868417937025e+05;
    xcrref(2) = 0.4696371050071e+04;
    xcrref(3) = 0.1218114549776e+05;
    xcrref(4) = 0.1033801493461e+05;
    xcrref(5) = 0.7142398413817e+05;
/* c--------------------------------------------------------------------- */
/* c   Reference values of RMS-norms of solution error, for the (408X408X408)  */
/* c   grid, after 300 time steps, with  DT = 1.0d+00 */
/* c--------------------------------------------------------------------- */
    xceref(1) = 0.3752393004482e+03;
    xceref(2) = 0.3084128893659e+02;
    xceref(3) = 0.9434276905469e+02;
    xceref(4) = 0.8230686681928e+02;
    xceref(5) = 0.7002620636210e+03;
/* c--------------------------------------------------------------------- */
/* c   Reference value of surface integral, for the (408X408X408) grid, */
/* c   after 300 time steps, with DT = 1.0d+00 */
/* c--------------------------------------------------------------------- */
    xciref =    0.8334101392503e+02;

  }else if ( (nx0 == 1020) && 
	     (ny0 == 1020) &&
	     (nz0 == 1020) &&
	     (itmax == 300) ){

    *class = 'E';
    dtref = 0.5e+0;
/* c--------------------------------------------------------------------- */
/* c   Reference values of RMS-norms of residual, for the (1020X1020X1020) grid, */
/* c   after 300 time steps, with  DT = 0.5d+00 */
/* c--------------------------------------------------------------------- */
    xcrref(1) = 0.2099641687874e+06;
    xcrref(2) = 0.2130403143165e+05;
    xcrref(3) = 0.5319228789371e+05;
    xcrref(4) = 0.4509761639833e+05;
    xcrref(5) = 0.2932360006590e+06;
/* c--------------------------------------------------------------------- */
/* c   Reference values of RMS-norms of solution error, for the (1020X1020X1020)  */
/* c   grid, after 300 time steps, with  DT = 0.5d+00 */
/* c--------------------------------------------------------------------- */
    xceref(1) = 0.4800572578333e+03;
    xceref(2) = 0.4221993400184e+02;
    xceref(3) = 0.1210851906824e+03;
    xceref(4) = 0.1047888986770e+03;
    xceref(5) = 0.8363028257389e+03;
/* c--------------------------------------------------------------------- */
/* c   Reference value of surface integral, for the (1020X1020X1020) grid, */
/* c   after 300 time steps, with DT = 0.5d+00 */
/* c--------------------------------------------------------------------- */
    xciref =    0.9512163272273e+02;

  }else{
    *verified = FALSE;
  } /* endif */

#if 0 /* ORIGINAL */
/* c--------------------------------------------------------------------- */
/* c    verification test for residuals if gridsize is either 12X12X12 or  */
/* c    64X64X64 or 102X102X102 or 162X162X162 */
/* c--------------------------------------------------------------------- */
#else
/* c--------------------------------------------------------------------- */
/* c    verification test for residuals if gridsize is one of  */
/* c    the defined grid sizes above (class .ne. 'U') */
/* c--------------------------------------------------------------------- */
#endif
/* c--------------------------------------------------------------------- */
/* c    Compute the difference of solution values and the known reference values. */
/* c--------------------------------------------------------------------- */
  for (m = 1; m <= 5; m ++){
    xcrdif(m) = dabs((xcr(m)-xcrref(m))/xcrref(m));
    xcedif(m) = dabs((xce(m)-xceref(m))/xceref(m));
  }
  xcidif = dabs((xci - xciref)/xciref);

/* c--------------------------------------------------------------------- */
/* c    Output the comparison of computed results to known cases. */
/* c--------------------------------------------------------------------- */
  if (*class != 'U'){
#pragma xmp task on  ProjArea(0)
    {
      printf("\n Verification being performed for class %c\n", *class);
      printf(" Accuracy setting for epsilon = %20.13e\n", epsilon);
    }
#if 0
    *verified = (dabs(dt-dtref) <= epsilon);
    if (!*verified){
#else
    if (dabs(dt-dtref) > epsilon){
      *verified = FALSE;
#endif
      *class = 'U';
#pragma xmp task on  ProjArea(0)
      printf(" DT does not match the reference value of %15.8e\n", dtref);
    } /* endif */
  }else{
#pragma xmp task on  ProjArea(0)
    printf(" Unknown class\n");
  } /* endif */

  if (*class != 'U'){
#pragma xmp task on  ProjArea(0)
    printf(" Comparison of RMS-norms of residual\n");
	     }else{
#pragma xmp task on  ProjArea(0)
    printf(" RMS-norms of residual\n");
  } /* endif */

#define  FORMAT_2010   " FAILURE: %2d  %20.13e%20.13e%20.13e\n"
#define  FORMAT_2011   "          %2d  %20.13e%20.13e%20.13e\n"
#define  FORMAT_2015   "          %2d  %20.13e\n"

  for (m = 1; m <= 5; m ++){
    if (*class == 'U'){
#pragma xmp task on  ProjArea(0)
      printf(FORMAT_2015, m, xcr(m));
    }else if (xcrdif(m) <= epsilon){
#pragma xmp task on  ProjArea(0)
      printf(FORMAT_2011, m,xcr(m),xcrref(m),xcrdif(m));
    }else{
      *verified = FALSE;
#pragma xmp task on  ProjArea(0)
      printf(FORMAT_2010, m,xcr(m),xcrref(m),xcrdif(m));
    } /* endif */
  } /* m */

  if (*class != 'U'){
#pragma xmp task on  ProjArea(0)
    printf(" Comparison of RMS-norms of solution error\n");
  }else{
#pragma xmp task on  ProjArea(0)
    printf(" RMS-norms of solution error\n");
  } /* endif */
        
  for (m = 1; m <= 5; m ++){
    if (*class == 'U'){
#pragma xmp task on  ProjArea(0)
      printf(FORMAT_2015, m, xce(m));
    }else if (xcedif(m) <= epsilon){
#pragma xmp task on  ProjArea(0)
      printf(FORMAT_2011, m,xce(m),xceref(m),xcedif(m));
    }else{
      *verified = FALSE;
#pragma xmp task on  ProjArea(0)
      printf(FORMAT_2010, m,xce(m),xceref(m),xcedif(m));
    } /* endif */
  } /* m */
        
  if (*class != 'U'){
#pragma xmp task on  ProjArea(0)
    printf(" Comparison of surface integral\n");
  }else{
#pragma xmp task on  ProjArea(0)
    printf(" Surface integral\n");
  } /* endif */

  if (*class == 'U'){
#pragma xmp task on  ProjArea(0)
    printf("              %20.13e\n", xci);
  }else if (xcidif <= epsilon){
#pragma xmp task on  ProjArea(0)
    printf("              %20.13e%20.13e%20.13e\n", xci, xciref, xcidif);
  }else{
    *verified = FALSE;
#pragma xmp task on  ProjArea(0)
    printf(" FAILURE:     %20.13e%20.13e%20.13e\n", xci, xciref, xcidif);
  } /* endif */

  if (*class == 'U'){
#pragma xmp task on  ProjArea(0)
    {
      printf(" No reference values provided\n");
      printf(" No verification performed\n");
    }
  }else if (*verified){
#pragma xmp task on  ProjArea(0)
    printf(" Verification Successful\n");
  }else{
#pragma xmp task on  ProjArea(0)
    printf(" Verification failed\n");
  } /* endif */
}
/* -------------------------------------------------------------------------- */
