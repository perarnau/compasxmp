#include "applu.h"
#include "proto.h"
#ifdef _XCALABLEMP
#include "xmp.h"
#endif
/* -------------------------------------------------------------------------- */
void read_input()
{
/* c--------------------------------------------------------------------- */
/* c    if input file does not exist, it uses defaults */
/* c       ipr = 1 for detailed progress output */
/* c       inorm = how often the norm is printed (once every inorm iterations) */
/* c       itmax = number of pseudo time steps */
/* c       dt = time step */
/* c       omega 1 over-relaxation factor for SSOR */
/* c       tolrsd = steady state residual tolerance levels */
/* c       nx, ny, nz = number of grid points in x, y, z directions */
/* c--------------------------------------------------------------------- */
  char buf[512];
#pragma xmp task on ProjArea(0)
  printf("\n\n NAS Parallel Benchmarks (NPB3.0-HPF) - LU Benchmark\n\n");

  FILE *fstatus = fopen("inputlu.data","r");
  if (fstatus != NULL){

    printf(" Reading from input file inputlu.data\n");
    fgets(buf,sizeof(buf),fstatus);
    fgets(buf,sizeof(buf),fstatus);
    fgets(buf,sizeof(buf),fstatus); sscanf(buf,"%d %d", &ipr, &inorm);
    fgets(buf,sizeof(buf),fstatus);
    fgets(buf,sizeof(buf),fstatus);
    fgets(buf,sizeof(buf),fstatus); sscanf(buf,"%d", &itmax);
    fgets(buf,sizeof(buf),fstatus);
    fgets(buf,sizeof(buf),fstatus);
    fgets(buf,sizeof(buf),fstatus); sscanf(buf,"%lf", &dt);
    fgets(buf,sizeof(buf),fstatus);
    fgets(buf,sizeof(buf),fstatus);
    fgets(buf,sizeof(buf),fstatus); sscanf(buf,"%lf", &omega);
    fgets(buf,sizeof(buf),fstatus);
    fgets(buf,sizeof(buf),fstatus);
    fgets(buf,sizeof(buf),fstatus); sscanf(buf,"%lf %lf %lf %lf %lf", &tolrsd(1), &tolrsd(2), &tolrsd(3), &tolrsd(4), &tolrsd(5));
    fgets(buf,sizeof(buf),fstatus);
    fgets(buf,sizeof(buf),fstatus);
    fgets(buf,sizeof(buf),fstatus); sscanf(buf,"%d %d %d", &nx0, &ny0, &nz0);
    fclose(fstatus);
  }else{
    ipr = ipr_default;
    inorm = inorm_default;
    itmax = itmax_default;
    dt = dt_default;
    omega = omega_default;
    tolrsd(1) = tolrsd1_def;
    tolrsd(2) = tolrsd2_def;
    tolrsd(3) = tolrsd3_def;
    tolrsd(4) = tolrsd4_def;
    tolrsd(5) = tolrsd5_def;
    nx0 = isiz1;
    ny0 = isiz2;
    nz0 = isiz3;
  } /* endif */
/* c--------------------------------------------------------------------- */
/* c   check problem size */
/* c--------------------------------------------------------------------- */
  if ( ( nx0 < 4 ) || ( ny0 < 4 ) || ( nz0 < 4 ) ){
#define FORMAT_2001  "     PROBLEM SIZE IS TOO SMALL - " \
                   "\n     SET EACH OF NX, NY AND NZ AT LEAST EQUAL TO 5\n"
    printf(FORMAT_2001);
    exit(1);
  } /* endif */

  if ( ( nx0 > isiz1 ) || ( ny0 > isiz2 ) || ( nz0 > isiz3 ) ){
#define FORMAT_2002  "     PROBLEM SIZE IS TOO LARGE - " \
                   "\n     NX, NY AND NZ SHOULD BE EQUAL TO " \
                   "\n     ISIZ1, ISIZ2 AND ISIZ3 RESPECTIVELY\n"
    printf(FORMAT_2002);
    exit(1);
  } /* endif */
#ifdef _XCALABLEMP
  int num_process = xmp_get_size();
#else
  int num_process = 1;
#endif
#pragma xmp task on ProjArea(0)
  {
  printf(" Size: %3dx%3dx%3d\n", nx0, ny0, nz0);
  printf(" Iterations: %3d\n", itmax);
  printf(" Number of active processes: %5d\n\n", num_process);
  }
}
/* -------------------------------------------------------------------------- */
